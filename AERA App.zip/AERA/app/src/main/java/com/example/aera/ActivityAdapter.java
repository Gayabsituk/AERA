package com.example.aera;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Locale;

public class ActivityAdapter extends RecyclerView.Adapter<ActivityAdapter.ViewHolder> {

    private List<ActivityEntry> list;

    public ActivityAdapter(List<ActivityEntry> list) {
        this.list = list;
    }

    public void updateList(List<ActivityEntry> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_activity_log, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ActivityEntry entry = list.get(position);
        holder.tvSubtype.setText(entry.getSubType());
        holder.tvType.setText(entry.getType());
        holder.tvCo2.setText(String.format(Locale.getDefault(), "%.1f kg", entry.getCo2e()));

        int iconRes = R.drawable.ic_transport;
        String hexTint = "#2D6A4F";

        String category = entry.getType() != null ? entry.getType() : "";
        switch (category) {
            case "Transport": iconRes = R.drawable.ic_transport; hexTint = "#2D6A4F"; break;
            case "Energy": iconRes = R.drawable.ic_energy; hexTint = "#D97706"; break;
            case "Food": iconRes = R.drawable.ic_food; hexTint = "#3730A3"; break;
            case "Shopping": iconRes = R.drawable.ic_shopping; hexTint = "#7C3AED"; break;
            case "Waste": iconRes = R.drawable.ic_waste; hexTint = "#606C38"; break;
        }

        holder.ivIcon.setImageResource(iconRes);
        holder.ivIcon.setColorFilter(Color.parseColor(hexTint));

        // Click to enter EDIT MODE
        holder.itemView.setOnClickListener(v -> {
            if (v.getContext() instanceof FragmentActivity) {
                LogActivityFragment editFragment = new LogActivityFragment();
                Bundle args = new Bundle();
                args.putInt("EDIT_ID", entry.getId());
                args.putString("SELECTED_CATEGORY", entry.getType());
                args.putString("EDIT_SUBTYPE", entry.getSubType());
                args.putDouble("EDIT_VALUE", entry.getValue());
                editFragment.setArguments(args);

                ((FragmentActivity) v.getContext()).getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, editFragment)
                        .addToBackStack(null)
                        .commit();
            }
        });
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivIcon;
        TextView tvSubtype, tvType, tvCo2;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.iv_activity_icon);
            tvSubtype = itemView.findViewById(R.id.tv_activity_subtype);
            tvType = itemView.findViewById(R.id.tv_activity_type);
            tvCo2 = itemView.findViewById(R.id.tv_activity_co2);
        }
    }
}