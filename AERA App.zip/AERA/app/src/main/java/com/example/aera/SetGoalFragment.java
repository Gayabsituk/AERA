package com.example.aera;

import androidx.appcompat.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;

public class SetGoalFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private Spinner spinnerPeriod, spinnerCategory;
    private EditText etTarget, etTitle;
    private ImageView ivPeriodArrow, ivCategoryArrow;
    private TextView tvHeaderTitle;
    private MaterialButton btnDelete;

    private int goalId = -1; // -1 means creating a new goal, otherwise it's an edit

    public static SetGoalFragment newInstance(int id, String title, int target, String period, String category) {
        SetGoalFragment fragment = new SetGoalFragment();
        Bundle args = new Bundle();
        args.putInt("id", id);
        args.putString("title", title);
        args.putInt("target", target);
        args.putString("period", period);
        args.putString("category", category);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_set_goal, container, false);
        dbHelper = new DatabaseHelper(requireContext());

        // Initialize Views
        spinnerPeriod = view.findViewById(R.id.spinner_goal_period);
        spinnerCategory = view.findViewById(R.id.spinner_goal_category);
        etTarget = view.findViewById(R.id.et_target_reduction);
        etTitle = view.findViewById(R.id.et_goal_title);
        tvHeaderTitle = view.findViewById(R.id.tv_set_goal_title);
        btnDelete = view.findViewById(R.id.btn_delete_goal);

        ivPeriodArrow = view.findViewById(R.id.iv_period_arrow);
        ivCategoryArrow = view.findViewById(R.id.iv_category_arrow);

        spinnerPeriod.setPopupBackgroundResource(R.drawable.bg_rounded_dropdown);
        spinnerCategory.setPopupBackgroundResource(R.drawable.bg_rounded_dropdown);

        // --- FIXED: ADDED BLANK DEFAULT OPTIONS ---
        String[] periods = {"", "Weekly", "Monthly", "Yearly"};
        String[] categories = {"", "Overall Footprint", "Transport", "Energy", "Food", "Shopping", "Waste"};

        ArrayAdapter<String> periodAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, periods);
        periodAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerPeriod.setAdapter(periodAdapter);

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, categories);
        categoryAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerCategory.setAdapter(categoryAdapter);

        setupSpinnerArrowBehavior(spinnerPeriod, ivPeriodArrow);
        setupSpinnerArrowBehavior(spinnerCategory, ivCategoryArrow);

        // CHECK FOR EXISTING DATA (Edit Mode vs Create Mode)
        if (getArguments() != null) {
            goalId = getArguments().getInt("id", -1);
            if (goalId != -1) {
                // EDIT MODE
                tvHeaderTitle.setText("Edit Goal");
                etTitle.setText(getArguments().getString("title", ""));
                etTarget.setText(String.valueOf(getArguments().getInt("target", 0)));

                spinnerPeriod.setSelection(getSpinnerIndex(spinnerPeriod, getArguments().getString("period", "")));
                spinnerCategory.setSelection(getSpinnerIndex(spinnerCategory, getArguments().getString("category", "")));

                // Reveal Delete Button in Edit Mode
                if (btnDelete != null) {
                    btnDelete.setVisibility(View.VISIBLE);
                    btnDelete.setOnClickListener(v -> confirmDelete());
                }
            } else {
                // CREATE MODE (Arguments exist but ID is -1)
                clearFormFields();
            }
        } else {
            // CREATE MODE (No arguments)
            clearFormFields();
        }

        // --- SAFEGUARDS FOR BACK BUTTON & BOTTOM NAV ---
        view.findViewById(R.id.btn_back).setOnClickListener(v -> showNavigationWarningDialog(-1));
        setupBottomNavigation();

        view.findViewById(R.id.btn_save_goal).setOnClickListener(v -> confirmSave());

        return view;
    }

    // --- FIXED: FORCES FIELDS TO BE BLANK ON STARTUP ---
    private void clearFormFields() {
        etTitle.setText("");
        etTarget.setText("");
        spinnerPeriod.setSelection(0); // Selects the blank "" option
        spinnerCategory.setSelection(0); // Selects the blank "" option
    }

    private void setupBottomNavigation() {
        if (getActivity() != null) {
            BottomNavigationView bottomNavigation = getActivity().findViewById(R.id.bottomNavigation);
            if (bottomNavigation != null) {
                bottomNavigation.setOnItemSelectedListener(item -> {
                    int itemId = item.getItemId();
                    if (itemId == R.id.nav_goals) return true; // Already on Goals

                    showNavigationWarningDialog(itemId);
                    return false; // Prevent tab from switching visually yet
                });
            }
        }
    }

    private void setupSpinnerArrowBehavior(Spinner spinner, ImageView arrowIcon) {
        spinner.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                arrowIcon.setImageResource(R.drawable.ic_chevron_up);
            }
            return false;
        });

        spinner.getViewTreeObserver().addOnWindowFocusChangeListener(hasFocus -> {
            if (hasFocus) {
                arrowIcon.setImageResource(R.drawable.ic_chevron_down);
            }
        });
    }

    private int getSpinnerIndex(Spinner spinner, String value) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(value)) {
                return i;
            }
        }
        return 0;
    }

    // --- REUSABLE CRASH-PROOF CUSTOM DIALOG ---
    private void showCustomDialog(String title, String message, String posText, String negText, String posColorHex, Runnable onPositive, Runnable onNegative) {
        if (!isAdded() || getContext() == null) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_layout, null);
        builder.setView(view);

        AlertDialog dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        TextView tvTitle = view.findViewById(R.id.tv_dialog_title);
        TextView tvMessage = view.findViewById(R.id.tv_dialog_message);
        TextView btnNegative = view.findViewById(R.id.btn_dialog_negative);
        TextView btnPositive = view.findViewById(R.id.btn_dialog_positive);

        if (tvTitle == null || btnPositive == null) {
            if (onPositive != null) onPositive.run();
            return;
        }

        tvTitle.setText(title);
        tvMessage.setText(message);

        if (btnNegative != null) {
            btnNegative.setText(negText);
            btnNegative.setOnClickListener(v -> {
                dialog.dismiss();
                if (onNegative != null) onNegative.run();
            });
        }

        btnPositive.setText(posText);
        btnPositive.setTextColor(Color.parseColor(posColorHex));
        btnPositive.setOnClickListener(v -> {
            dialog.dismiss();
            if (onPositive != null) onPositive.run();
        });

        dialog.show();
    }

    private void showNavigationWarningDialog(int targetItemId) {
        showCustomDialog(
                "Discard Changes?",
                "Are you sure you want to discard your current progress and leave this page?",
                "Discard",
                "Cancel",
                "#D32F2F", // Red Discard
                () -> navigateAway(targetItemId),
                null
        );
    }

    private void navigateAway(int itemId) {
        if (itemId == -1) {
            getParentFragmentManager().popBackStack();
            return;
        }

        if (!isAdded() || getActivity() == null) return;

        requireActivity().getSupportFragmentManager().popBackStack();

        Fragment selectedFragment = null;
        if (itemId == R.id.nav_home) selectedFragment = new HomePageFragment();
        else if (itemId == R.id.nav_activity) selectedFragment = new ActivityLogFragment();
        else if (itemId == R.id.nav_analytics) selectedFragment = new AnalyticsFragment();
        else if (itemId == R.id.nav_settings) selectedFragment = new SettingsFragment();

        if (selectedFragment != null) {
            requireActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, selectedFragment)
                    .commit();

            if (getActivity() instanceof Aera) {
                ((Aera) getActivity()).updateBottomNavSelection(itemId);
            }
        }
    }

    private void confirmSave() {
        String title = etTitle.getText().toString().trim();
        String targetStr = etTarget.getText().toString().trim();

        if (title.isEmpty()) {
            etTitle.setError("Required");
            etTitle.requestFocus();
            return;
        }

        // --- NEW: Block saving if Dropdowns are left blank ---
        if (spinnerPeriod.getSelectedItemPosition() == 0) {
            Toast.makeText(requireContext(), "Please select a Goal Period", Toast.LENGTH_SHORT).show();
            return;
        }

        if (targetStr.isEmpty()) {
            etTarget.setError("Required");
            etTarget.requestFocus();
            return;
        }

        if (spinnerCategory.getSelectedItemPosition() == 0) {
            Toast.makeText(requireContext(), "Please select a Category", Toast.LENGTH_SHORT).show();
            return;
        }

        String dialogTitle = goalId == -1 ? "Save Goal" : "Save Changes";
        String dialogMessage = goalId == -1 ? "Are you sure you want to create this goal?" : "Are you sure you want to save these changes?";

        showCustomDialog(
                dialogTitle,
                dialogMessage,
                "Yes",
                "Cancel",
                "#2E7D32", // Green Yes
                () -> executeSave(title, targetStr),
                null
        );
    }

    private void confirmDelete() {
        showCustomDialog(
                "Delete Goal",
                "Do you want to continue deletion or cancel?",
                "Continue",
                "Cancel",
                "#D32F2F", // Red Continue
                () -> {
                    try {
                        dbHelper.deleteGoal(goalId);
                        Toast.makeText(requireContext(), "Goal Deleted!", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {}
                    getParentFragmentManager().popBackStack();
                },
                null // Do nothing on Cancel, stay on editing page
        );
    }

    private void executeSave(String title, String targetStr) {
        int target = Integer.parseInt(targetStr);
        String period = spinnerPeriod.getSelectedItem().toString();
        String category = spinnerCategory.getSelectedItem().toString();
        String desc = "Reduce " + category.toLowerCase() + " by " + target + "% this " + period.toLowerCase().replace("ly", "");

        if (goalId == -1) {
            dbHelper.addGoal(title, desc, target, period, category);
            Toast.makeText(requireContext(), "Goal Set!", Toast.LENGTH_SHORT).show();
        } else {
            dbHelper.updateGoal(goalId, title, desc, target, period, category);
            Toast.makeText(requireContext(), "Goal Updated!", Toast.LENGTH_SHORT).show();
        }

        getParentFragmentManager().popBackStack();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() instanceof Aera) {
            ((Aera) getActivity()).setBottomNavigationVisibility(true);
        }
    }
}