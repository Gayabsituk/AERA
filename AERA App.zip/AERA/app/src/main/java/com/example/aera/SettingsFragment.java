package com.example.aera;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SettingsFragment extends Fragment {

    private TextView profileSubtext;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.settings_page, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Show the bottom nav and keep the Settings tab highlighted
        if (getActivity() instanceof Aera) {
            ((Aera) getActivity()).setBottomNavigationVisibility(true);
            ((Aera) getActivity()).updateBottomNavSelection(R.id.nav_settings);
        }

        // Show the stored username on the Profile row
        SharedPreferences prefs = requireActivity().getSharedPreferences("AeraPrefs", Context.MODE_PRIVATE);
        String userName = prefs.getString("user_name", getString(R.string.hev_abi));
        profileSubtext = view.findViewById(R.id.profileSubtext);
        if (profileSubtext != null && userName != null && !userName.isEmpty()) {
            profileSubtext.setText(userName);
        }

        // Open Edit Username Dialog on Profile Row Click
        View profileRow = view.findViewById(R.id.profileRow);
        if (profileRow != null) {
            profileRow.setOnClickListener(v -> showEditUsernameDialog(userName));
        }

        // Open the Computations screen
        View computationsRow = view.findViewById(R.id.computationsRow);
        if (computationsRow != null) {
            computationsRow.setOnClickListener(v ->
                    ((Aera) requireActivity()).switchFragment(new ComputationsFragment(), true));
        }

        // Open About AERA Dialog
        View aboutRow = view.findViewById(R.id.aboutRow);
        if (aboutRow != null) {
            aboutRow.setOnClickListener(v -> showAboutDialog());
        }

        // Handle Logout Button
        View logoutRow = view.findViewById(R.id.logoutRow);
        if (logoutRow != null) {
            logoutRow.setOnClickListener(v -> showLogoutConfirmationDialog());
        }
    }

    private void showEditUsernameDialog(String currentName) {
        if (!isAdded() || getContext() == null) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_edit_username, null);
        builder.setView(view);

        AlertDialog dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        EditText etUsernameInput = view.findViewById(R.id.et_username_input);
        TextView btnNegative = view.findViewById(R.id.btn_dialog_negative);
        TextView btnPositive = view.findViewById(R.id.btn_dialog_positive);

        if (etUsernameInput != null && currentName != null) {
            etUsernameInput.setText(currentName);
            etUsernameInput.setSelection(currentName.length()); // Move cursor to the end
        }

        if (btnNegative != null) {
            btnNegative.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnPositive != null) {
            btnPositive.setOnClickListener(v -> {
                if (etUsernameInput != null) {
                    String newName = etUsernameInput.getText().toString().trim();
                    if (!newName.isEmpty()) {
                        // Save to SharedPreferences
                        SharedPreferences prefs = requireActivity().getSharedPreferences("AeraPrefs", Context.MODE_PRIVATE);
                        prefs.edit().putString("user_name", newName).apply();

                        // Update UI instantly
                        if (profileSubtext != null) {
                            profileSubtext.setText(newName);
                        }

                        Toast.makeText(requireContext(), "Username updated!", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    } else {
                        etUsernameInput.setError("Name cannot be empty");
                    }
                }
            });
        }

        dialog.show();
    }

    private void showAboutDialog() {
        if (!isAdded() || getContext() == null) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_about_aera, null);
        builder.setView(view);

        AlertDialog dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        TextView btnClose = view.findViewById(R.id.btn_about_close);
        if (btnClose != null) {
            btnClose.setOnClickListener(v -> dialog.dismiss());
        }

        dialog.show();
    }

    private void showLogoutConfirmationDialog() {
        if (!isAdded() || getContext() == null) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_layout, null);
        builder.setView(view);

        AlertDialog dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        TextView tvTitle = view.findViewById(R.id.tv_dialog_title);
        TextView tvMessage = view.findViewById(R.id.tv_dialog_message);
        TextView btnNegative = view.findViewById(R.id.btn_dialog_negative);
        TextView btnPositive = view.findViewById(R.id.btn_dialog_positive);

        if (tvTitle != null) tvTitle.setText("Log Out");
        if (tvMessage != null) tvMessage.setText("Are you sure you want to log out of your account?");

        if (btnNegative != null) {
            btnNegative.setText("Cancel");
            btnNegative.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnPositive != null) {
            btnPositive.setText("Log Out");
            btnPositive.setTextColor(Color.parseColor("#D32F2F")); // Red for logout
            btnPositive.setOnClickListener(v -> {
                dialog.dismiss();
                performLogout();
            });
        }

        dialog.show();
    }

    private void performLogout() {
        SharedPreferences prefs = requireActivity().getSharedPreferences("AeraPrefs", Context.MODE_PRIVATE);
        prefs.edit().clear().apply();

        Toast.makeText(requireContext(), "Logged out successfully", Toast.LENGTH_SHORT).show();
    }
}