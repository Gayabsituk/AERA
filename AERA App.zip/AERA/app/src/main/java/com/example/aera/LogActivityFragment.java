package com.example.aera;

import androidx.appcompat.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;
import java.util.HashMap;
import java.util.Map;

public class LogActivityFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private String currentCategory = "Transport";
    private int editId = -1;

    // UI Elements
    private LinearLayout layoutTransport, layoutEnergy, layoutGeneral;
    private ChipGroup chipGroup;
    private Spinner spinnerTransport, spinnerSubtype;
    private ImageView ivTransportArrow, ivSubtypeArrow, ivSubtypeLeftIcon;
    private EditText etDistance, etTrips, etPassengers, etKwh, etAmount;
    private TextView tvEstimatedFootprint, tvSubtypeLabel, tvAmountLabel, tvUnit, tvTitle;
    private MaterialButton btnSave, btnDelete;

    // Data Factors
    private final Map<String, Double> transportFactors = new HashMap<>();
    private final Map<String, Double> foodFactors = new HashMap<>();
    private final Map<String, Double> shoppingFactors = new HashMap<>();
    private final Map<String, Double> wasteFactors = new HashMap<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.log_activity, container, false);

        if (getActivity() instanceof Aera) {
            ((Aera) requireActivity()).setBottomNavigationVisibility(false);
        }

        dbHelper = new DatabaseHelper(requireContext());

        initData();
        initViews(view);
        setupCategorySwitching();
        setupRealTimeCalculation();
        setupBottomNavigation(view);

        // Safeguard back button
        view.findViewById(R.id.btn_back).setOnClickListener(v -> showNavigationWarningDialog(-1));

        btnSave.setText("Save Activity");

        btnSave.setOnClickListener(v -> {
            if (editId != -1) {
                confirmUpdate();
            } else {
                saveEntry();
            }
        });

        if (getArguments() != null) {
            editId = getArguments().getInt("EDIT_ID", -1);
            String passedCategory = getArguments().getString("SELECTED_CATEGORY", "Transport");
            selectCategoryChip(passedCategory);

            if (editId != -1) {
                btnSave.setText("Save Activity");
                if (tvTitle != null) tvTitle.setText("Edit Activity");

                if (btnDelete != null) {
                    btnDelete.setVisibility(View.VISIBLE);
                    btnDelete.setText("Delete Activity");
                    btnDelete.setOnClickListener(v -> confirmDelete());
                }

                double val = getArguments().getDouble("EDIT_VALUE", 0);
                String subtype = getArguments().getString("EDIT_SUBTYPE", "");

                view.post(() -> {
                    if (passedCategory.equals("Transport")) {
                        etDistance.setText(val == (long) val ? String.format(java.util.Locale.getDefault(), "%d", (long) val) : String.valueOf(val));
                        etTrips.setText("1");
                        etPassengers.setText("1");
                        setSpinnerSelection(spinnerTransport, subtype);
                    } else if (passedCategory.equals("Energy")) {
                        etKwh.setText(val == (long) val ? String.format(java.util.Locale.getDefault(), "%d", (long) val) : String.valueOf(val));
                    } else {
                        etAmount.setText(val == (long) val ? String.format(java.util.Locale.getDefault(), "%d", (long) val) : String.valueOf(val));
                        setSpinnerSelection(spinnerSubtype, subtype);
                    }
                    calculateFootprint();
                });
            }
        }

        return view;
    }

    private void setupBottomNavigation(View view) {
        BottomNavigationView bottomNavigation = view.findViewById(R.id.bottomNavigation);
        if (bottomNavigation != null) {
            bottomNavigation.setSelectedItemId(R.id.nav_activity);

            bottomNavigation.setOnItemSelectedListener(item -> {
                int itemId = item.getItemId();
                if (itemId == R.id.nav_activity) return true;

                showNavigationWarningDialog(itemId);
                return false;
            });
        }
    }

    private void showCustomDialog(String title, String message, String posText, String negText, String posColorHex, Runnable onPositive, Runnable onNegative) {
        if (!isAdded() || getActivity() == null) return;

        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
            View view = getLayoutInflater().inflate(R.layout.dialog_layout, null);
            builder.setView(view);

            AlertDialog dialog = builder.create();

            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }

            TextView tvTitle = view.findViewById(R.id.tv_dialog_title);
            TextView tvMessage = view.findViewById(R.id.tv_dialog_message);
            TextView btnNegative = view.findViewById(R.id.btn_dialog_negative);
            TextView btnPositive = view.findViewById(R.id.btn_dialog_positive);

            // CRASH PREVENTION: If dialog_layout.xml is empty/missing IDs, bypass the dialog and execute directly.
            if (tvTitle == null || btnPositive == null) {
                if (onPositive != null) onPositive.run();
                return;
            }

            tvTitle.setText(title);
            tvMessage.setText(message);

            if (btnNegative != null) {
                btnNegative.setText(negText);
                btnNegative.setOnClickListener(v -> {
                    dialog.dismiss();
                    if (onNegative != null) onNegative.run();
                });
            }

            btnPositive.setText(posText);
            btnPositive.setTextColor(Color.parseColor(posColorHex));
            btnPositive.setOnClickListener(v -> {
                dialog.dismiss();
                if (onPositive != null) onPositive.run();
            });

            dialog.show();

        } catch (Exception e) {
            // Ultimate fallback to prevent the app from stopping
            if (onPositive != null) onPositive.run();
        }
    }

    private void showNavigationWarningDialog(int targetItemId) {
        showCustomDialog(
                "Discard Changes?",
                "Are you sure you want to discard your current progress and leave this page?",
                "Discard",
                "Cancel",
                "#D32F2F", // Red Discard
                () -> navigateAway(targetItemId),
                null
        );
    }

    private void confirmUpdate() {
        if (!validateInputs()) return;
        showCustomDialog(
                "Save Activity",
                "Do you want to save this activity or discard your changes?",
                "Save",
                "Discard",
                "#2E7D32", // Green Save
                this::executeSave,
                this::returnToActivityLog
        );
    }

    private void confirmDelete() {
        showCustomDialog(
                "Delete Activity",
                "Do you want to continue deletion or cancel?",
                "Continue",
                "Cancel",
                "#D32F2F", // Red Continue
                () -> {
                    try {
                        dbHelper.deleteActivity(editId);
                        Toast.makeText(requireContext(), "Activity Deleted!", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {}
                    returnToActivityLog();
                },
                this::returnToActivityLog
        );
    }

    private void returnToActivityLog() {
        if (!isAdded() || getActivity() == null) return;

        getActivity().getSupportFragmentManager().popBackStack();

        if (getActivity() instanceof Aera) {
            ((Aera) getActivity()).updateBottomNavSelection(R.id.nav_activity);
            ((Aera) getActivity()).setBottomNavigationVisibility(true);
        }
    }

    private void navigateAway(int itemId) {
        if (itemId == -1) {
            returnToActivityLog();
            return;
        }

        if (!isAdded() || getActivity() == null) return;

        requireActivity().getSupportFragmentManager().popBackStack();

        Fragment selectedFragment = null;
        if (itemId == R.id.nav_home) selectedFragment = new HomePageFragment();
        else if (itemId == R.id.nav_analytics) selectedFragment = new AnalyticsFragment();
        else if (itemId == R.id.nav_goals) selectedFragment = new GoalsFragment();
        else if (itemId == R.id.nav_settings) selectedFragment = new SettingsFragment();

        if (selectedFragment != null) {
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, selectedFragment)
                    .commit();

            if (getActivity() instanceof Aera) {
                ((Aera) getActivity()).updateBottomNavSelection(itemId);
                ((Aera) getActivity()).setBottomNavigationVisibility(true);
            }
        }
    }

    private void setSpinnerSelection(Spinner spinner, String value) {
        if (spinner.getAdapter() == null) return;
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(value)) {
                spinner.setSelection(i);
                break;
            }
        }
    }

    private void selectCategoryChip(String category) {
        switch (category) {
            case "Transport": chipGroup.check(R.id.chip_transport); break;
            case "Energy": chipGroup.check(R.id.chip_energy); break;
            case "Food": chipGroup.check(R.id.chip_food); break;
            case "Shopping": chipGroup.check(R.id.chip_shopping); break;
            case "Waste": chipGroup.check(R.id.chip_waste); break;
        }
    }

    private void initData() {
        transportFactors.put("Motorcycle", 0.266);
        transportFactors.put("Tricycle", 0.266);
        transportFactors.put("Car", 0.319);
        transportFactors.put("Taxi", 0.292);
        transportFactors.put("Jeepney", 0.415);
        transportFactors.put("Bus", 1.097);
        transportFactors.put("UV/Van", 0.415);

        foodFactors.put("High-Impact Meat", 27.0);
        foodFactors.put("Medium-Impact Meat", 8.0);
        foodFactors.put("Low-Impact Meat", 6.0);
        foodFactors.put("Seafood", 5.0);
        foodFactors.put("Dairy & Eggs", 4.0);
        foodFactors.put("Grains & Staples", 2.5);
        foodFactors.put("Fruits & Vegetables", 0.9);
        foodFactors.put("Legumes & Plant-Based", 1.0);
        foodFactors.put("Processed & Packaged", 2.5);
        foodFactors.put("Sweets & Desserts", 5.0);
        foodFactors.put("Beverages", 1.5);

        shoppingFactors.put("Clothing & Footwear", 15.0);
        shoppingFactors.put("Electronics", 100.0);
        shoppingFactors.put("Furniture", 50.0);
        shoppingFactors.put("Household Products", 5.0);
        shoppingFactors.put("Personal Care", 2.0);
        shoppingFactors.put("Paper Products", 1.5);
        shoppingFactors.put("Plastic Products", 3.0);
        shoppingFactors.put("Other Retail Goods", 5.0);

        wasteFactors.put("Food Waste", 0.5);
        wasteFactors.put("Paper & Cardboard", 1.5);
        wasteFactors.put("Plastic", 3.0);
        wasteFactors.put("Glass", 0.9);
        wasteFactors.put("Metal", 2.0);
        wasteFactors.put("Textiles", 5.0);
        wasteFactors.put("Electronic Waste", 20.0);
        wasteFactors.put("Mixed/General Waste", 2.0);
    }

    private void initViews(View view) {
        layoutTransport = view.findViewById(R.id.layout_transport);
        layoutEnergy = view.findViewById(R.id.layout_energy);
        layoutGeneral = view.findViewById(R.id.layout_general);
        chipGroup = view.findViewById(R.id.chip_group_category);

        btnSave = view.findViewById(R.id.btn_save);
        btnDelete = view.findViewById(R.id.btn_delete);
        tvTitle = view.findViewById(R.id.tv_page_title);

        spinnerTransport = view.findViewById(R.id.spinner_transport_type);
        spinnerSubtype = view.findViewById(R.id.spinner_subtype);

        ivTransportArrow = view.findViewById(R.id.iv_transport_arrow);
        ivSubtypeArrow = view.findViewById(R.id.iv_subtype_arrow);
        ivSubtypeLeftIcon = view.findViewById(R.id.iv_subtype_left_icon);

        etDistance = view.findViewById(R.id.et_distance);
        etTrips = view.findViewById(R.id.et_trips);
        etPassengers = view.findViewById(R.id.et_passengers);
        etKwh = view.findViewById(R.id.et_kwh);
        etAmount = view.findViewById(R.id.et_amount);

        tvEstimatedFootprint = view.findViewById(R.id.tv_estimated_footprint);
        tvSubtypeLabel = view.findViewById(R.id.tv_subtype_label);
        tvAmountLabel = view.findViewById(R.id.tv_amount_label);
        tvUnit = view.findViewById(R.id.tv_unit);

        setupSpinner(spinnerTransport, transportFactors.keySet().toArray(new String[0]));
    }

    private void setupCategorySwitching() {
        chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int checkedId = checkedIds.get(0);

            layoutTransport.setVisibility(View.GONE);
            layoutEnergy.setVisibility(View.GONE);
            layoutGeneral.setVisibility(View.GONE);
            tvUnit.setVisibility(View.VISIBLE);

            if (checkedId == R.id.chip_transport) {
                currentCategory = "Transport";
                layoutTransport.setVisibility(View.VISIBLE);
            } else if (checkedId == R.id.chip_energy) {
                currentCategory = "Energy";
                layoutEnergy.setVisibility(View.VISIBLE);
            } else if (checkedId == R.id.chip_food) {
                currentCategory = "Food";
                layoutGeneral.setVisibility(View.VISIBLE);
                updateGeneralUI("Food Type", "Serving/Amount", "kg", foodFactors.keySet().toArray(new String[0]));
            } else if (checkedId == R.id.chip_shopping) {
                currentCategory = "Shopping";
                layoutGeneral.setVisibility(View.VISIBLE);
                updateGeneralUI("Category", "Number of Items", "", shoppingFactors.keySet().toArray(new String[0]));
                tvUnit.setVisibility(View.GONE);
            } else if (checkedId == R.id.chip_waste) {
                currentCategory = "Waste";
                layoutGeneral.setVisibility(View.VISIBLE);
                updateGeneralUI("Type of Waste", "Weight", "kg", wasteFactors.keySet().toArray(new String[0]));
            }
            calculateFootprint();
        });
    }

    private void updateGeneralUI(String label, String amountLabel, String unit, String[] types) {
        tvSubtypeLabel.setText(label);
        tvAmountLabel.setText(amountLabel);
        tvUnit.setText(unit);
        setupSpinner(spinnerSubtype, types);
    }

    private void setupSpinner(Spinner spinner, String[] items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                calculateFootprint();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupRealTimeCalculation() {
        TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { calculateFootprint(); }
            @Override public void afterTextChanged(Editable s) {}
        };
        etDistance.addTextChangedListener(tw);
        etTrips.addTextChangedListener(tw);
        etPassengers.addTextChangedListener(tw);
        etKwh.addTextChangedListener(tw);
        etAmount.addTextChangedListener(tw);
    }

    private void calculateFootprint() {
        double result = 0;
        switch (currentCategory) {
            case "Transport":
                if (spinnerTransport.getSelectedItem() != null) {
                    double dist = getDouble(etDistance);
                    double trips = getDouble(etTrips);
                    double pass = getDouble(etPassengers);
                    if (pass == 0) pass = 1;
                    result = (dist * trips * transportFactors.getOrDefault(spinnerTransport.getSelectedItem().toString(), 0.0)) / pass;
                }
                break;
            case "Energy":
                result = getDouble(etKwh) * 0.70;
                break;
            case "Food":
                if (spinnerSubtype.getSelectedItem() != null) result = getDouble(etAmount) * foodFactors.getOrDefault(spinnerSubtype.getSelectedItem().toString(), 0.0);
                break;
            case "Shopping":
                if (spinnerSubtype.getSelectedItem() != null) result = getDouble(etAmount) * shoppingFactors.getOrDefault(spinnerSubtype.getSelectedItem().toString(), 0.0);
                break;
            case "Waste":
                if (spinnerSubtype.getSelectedItem() != null) result = getDouble(etAmount) * wasteFactors.getOrDefault(spinnerSubtype.getSelectedItem().toString(), 0.0);
                break;
        }
        tvEstimatedFootprint.setText(String.format(java.util.Locale.getDefault(), "%.2f kg CO₂e", result));
    }

    // --- NEW: Prompts user before saving a new log ---
    private void saveEntry() {
        if (!validateInputs()) return;

        showCustomDialog(
                "Save Activity",
                "Are you sure you want to log this activity?",
                "Save",
                "Cancel",
                "#2E7D32", // Green Save
                this::executeSave,
                null // Do nothing on Cancel, stay on the page
        );
    }

    private void executeSave() {
        double co2e = 0;
        try {
            co2e = Double.parseDouble(tvEstimatedFootprint.getText().toString().split(" ")[0]);
        } catch (Exception e) {}

        String subtype = "";
        double val = 0;
        switch (currentCategory) {
            case "Transport":
                subtype = spinnerTransport.getSelectedItem() != null ? spinnerTransport.getSelectedItem().toString() : "Unknown";
                val = getDouble(etDistance);
                break;
            case "Energy":
                subtype = "Electricity";
                val = getDouble(etKwh);
                break;
            default:
                subtype = spinnerSubtype.getSelectedItem() != null ? spinnerSubtype.getSelectedItem().toString() : "Unknown";
                val = getDouble(etAmount);
                break;
        }

        try {
            if (editId == -1) {
                dbHelper.addActivity(currentCategory, subtype, val, co2e);
                Toast.makeText(requireContext(), "Activity Logged!", Toast.LENGTH_SHORT).show();
            } else {
                dbHelper.updateActivity(editId, currentCategory, subtype, val, co2e);
                Toast.makeText(requireContext(), "Activity Updated!", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {}

        returnToActivityLog();
    }

    private boolean validateInputs() {
        boolean valid = true;
        switch (currentCategory) {
            case "Transport":
                if (etDistance.getText().toString().isEmpty()) { etDistance.setError("Required"); valid = false; }
                break;
            case "Energy":
                if (etKwh.getText().toString().isEmpty()) { etKwh.setError("Required"); valid = false; }
                break;
            default:
                if (etAmount.getText().toString().isEmpty()) { etAmount.setError("Required"); valid = false; }
                break;
        }
        return valid;
    }

    private double getDouble(EditText et) {
        try { return Double.parseDouble(et.getText().toString()); }
        catch (Exception e) { return 0; }
    }
}