package com.example.aera;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class CompletedGoalAdapter extends RecyclerView.Adapter<CompletedGoalAdapter.GoalViewHolder> {

    private List<Goal> goalList = new ArrayList<>();

    public void updateList(List<Goal> newList) {
        goalList.clear();
        goalList.addAll(newList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public GoalViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Connects to your new layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_goal_completed, parent, false);
        return new GoalViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GoalViewHolder holder, int position) {
        Goal goal = goalList.get(position);
        holder.tvTitle.setText(goal.getTitle());
        holder.tvCategory.setText("Category: " + goal.getCategory());
        holder.tvDescription.setText(goal.getDescription());
    }

    @Override
    public int getItemCount() {
        return goalList.size();
    }

    static class GoalViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvCategory, tvDescription;

        public GoalViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvCategory = itemView.findViewById(R.id.tv_category);
            tvDescription = itemView.findViewById(R.id.tv_description);
        }
    }
}