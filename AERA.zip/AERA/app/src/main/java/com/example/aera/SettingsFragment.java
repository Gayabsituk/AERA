package com.example.aera;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SettingsFragment extends Fragment {

    private TextView profileSubtext;
    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.settings_page, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper = new DatabaseHelper(requireContext());

        if (getActivity() instanceof Aera) {
            ((Aera) getActivity()).setBottomNavigationVisibility(true);
            ((Aera) getActivity()).updateBottomNavSelection(R.id.nav_settings);
        }

        // Pull username safely from DB (fallback to SharedPreferences)
        String userName = dbHelper.getUserName();
        if (userName == null || userName.isEmpty()) {
            SharedPreferences prefs = requireActivity().getSharedPreferences("AeraPrefs", Context.MODE_PRIVATE);
            userName = prefs.getString("user_name", getString(R.string.hev_abi));
        }

        profileSubtext = view.findViewById(R.id.profileSubtext);
        if (profileSubtext != null && userName != null && !userName.isEmpty()) {
            profileSubtext.setText(userName);
        }

        View profileRow = view.findViewById(R.id.profileRow);
        if (profileRow != null) {
            String finalUserName = userName;
            profileRow.setOnClickListener(v -> showEditUsernameDialog(finalUserName));
        }

        View computationsRow = view.findViewById(R.id.computationsRow);
        if (computationsRow != null) {
            computationsRow.setOnClickListener(v ->
                    ((Aera) requireActivity()).switchFragment(new ComputationsFragment(), true));
        }

        View aboutRow = view.findViewById(R.id.aboutRow);
        if (aboutRow != null) {
            aboutRow.setOnClickListener(v -> showAboutDialog());
        }

        View logoutRow = view.findViewById(R.id.logoutRow);
        if (logoutRow != null) {
            logoutRow.setOnClickListener(v -> showLogoutConfirmationDialog());
        }
    }

    private void showEditUsernameDialog(String currentName) {
        if (!isAdded() || getContext() == null) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_edit_username, null);
        builder.setView(view);

        AlertDialog dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        EditText etUsernameInput = view.findViewById(R.id.et_username_input);
        TextView btnNegative = view.findViewById(R.id.btn_dialog_negative);
        TextView btnPositive = view.findViewById(R.id.btn_dialog_positive);

        if (etUsernameInput != null && currentName != null) {
            etUsernameInput.setText(currentName);
            etUsernameInput.setSelection(currentName.length());
        }

        if (btnNegative != null) {
            btnNegative.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnPositive != null) {
            btnPositive.setOnClickListener(v -> {
                if (etUsernameInput != null) {
                    String newName = etUsernameInput.getText().toString().trim();
                    if (!newName.isEmpty()) {

                        // 1. Save to SharedPreferences
                        SharedPreferences prefs = requireActivity().getSharedPreferences("AeraPrefs", Context.MODE_PRIVATE);
                        prefs.edit().putString("user_name", newName).apply();

                        // 2. Save to Database
                        dbHelper.setUserName(newName);

                        if (profileSubtext != null) {
                            profileSubtext.setText(newName);
                        }

                        Toast.makeText(requireContext(), "Username updated!", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    } else {
                        etUsernameInput.setError("Name cannot be empty");
                    }
                }
            });
        }

        dialog.show();
    }

    private void showAboutDialog() {
        if (!isAdded() || getContext() == null) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_about_aera, null);
        builder.setView(view);

        AlertDialog dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        TextView btnClose = view.findViewById(R.id.btn_about_close);
        if (btnClose != null) {
            btnClose.setOnClickListener(v -> dialog.dismiss());
        }

        dialog.show();
    }

    private void showLogoutConfirmationDialog() {
        if (!isAdded() || getContext() == null) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_layout, null);
        builder.setView(view);

        AlertDialog dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        TextView tvTitle = view.findViewById(R.id.tv_dialog_title);
        TextView tvMessage = view.findViewById(R.id.tv_dialog_message);
        TextView btnNegative = view.findViewById(R.id.btn_dialog_negative);
        TextView btnPositive = view.findViewById(R.id.btn_dialog_positive);

        if (tvTitle != null) tvTitle.setText("Log Out");
        if (tvMessage != null) tvMessage.setText("Are you sure you want to log out of your account?");

        if (btnNegative != null) {
            btnNegative.setText("Cancel");
            btnNegative.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnPositive != null) {
            btnPositive.setText("Log Out");
            btnPositive.setTextColor(Color.parseColor("#D32F2F"));
            btnPositive.setOnClickListener(v -> {
                dialog.dismiss();
                performLogout();
            });
        }

        dialog.show();
    }

    private void performLogout() {
        // 1. Clear SharedPreferences
        SharedPreferences prefs = requireActivity().getSharedPreferences("AeraPrefs", Context.MODE_PRIVATE);
        prefs.edit().remove("user_name").apply();

        // 2. Clear SQLite Session (Activities and Goals are left untouched!)
        if (dbHelper != null) {
            dbHelper.clearUserSession();
        }

        // 3. Hide bottom nav
        if (getActivity() instanceof Aera) {
            ((Aera) getActivity()).setBottomNavigationVisibility(false);
        }

        // 4. Navigate to GetStartedFragment
        requireActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, new GetStartedFragment())
                .commit();

        Toast.makeText(requireContext(), "Logged out successfully", Toast.LENGTH_SHORT).show();
    }
}