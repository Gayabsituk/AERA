package com.example.aera;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.aera.ActivityEntry;
import java.util.List;
import java.util.Locale;

public class ActivityAdapter extends RecyclerView.Adapter<ActivityAdapter.ViewHolder> {

    private List<ActivityEntry> list;

    public ActivityAdapter(List<ActivityEntry> list) {
        this.list = list;
    }

    public void updateList(List<ActivityEntry> list) {
        this.list = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_activity_log, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ActivityEntry entry = list.get(position);
        holder.tvSubtype.setText(entry.getSubType());
        holder.tvType.setText(entry.getType());
        holder.tvCo2.setText(String.format(Locale.getDefault(), "%.1f kg", entry.getCo2e()));

        int iconRes = R.drawable.ic_transport;
        String hexTint = "#2D6A4F";   // Default Green

        String category = entry.getType() != null ? entry.getType() : "";
        switch (category) {
            case "Transport":
                iconRes = R.drawable.ic_transport;
                hexTint = "#2D6A4F";   // Green
                break;
            case "Energy":
                iconRes = R.drawable.ic_energy;
                hexTint = "#D97706";   // Orange
                break;
            case "Food":
                iconRes = R.drawable.ic_food;
                hexTint = "#3730A3";   // Indigo
                break;
            case "Shopping":
                iconRes = R.drawable.ic_shopping;
                hexTint = "#7C3AED";   // Purple

                break;
            case "Waste":
                iconRes = R.drawable.ic_waste;
                hexTint = "#606C38";   // Olive

                break;
        }

        holder.ivIcon.setImageResource(iconRes);
        holder.ivIcon.setColorFilter(Color.parseColor(hexTint));


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivIcon;
        TextView tvSubtype, tvType, tvCo2;
        View iconContainer;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.iv_activity_icon);
            tvSubtype = itemView.findViewById(R.id.tv_activity_subtype);
            tvType = itemView.findViewById(R.id.tv_activity_type);
            tvCo2 = itemView.findViewById(R.id.tv_activity_co2);
            iconContainer = ivIcon.getParent() instanceof View ? (View) ivIcon.getParent() : null;
        }
    }
}