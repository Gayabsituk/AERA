package com.example.aera;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

public class MockDataHelper {

    public static void seedRealisticMonthlyData(DatabaseHelper dbHelper) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String targetUser = "Angela";

        dbHelper.setUserName(targetUser);

        db.delete(DatabaseHelper.TABLE_ACTIVITY, DatabaseHelper.COLUMN_USERNAME + " = ?", new String[]{targetUser});
        db.delete(DatabaseHelper.TABLE_GOALS, DatabaseHelper.COLUMN_GOAL_USERNAME + " = ?", new String[]{targetUser});

        db.beginTransaction();
        try {
            insertActivityRaw(db, targetUser, "Transport", "Bus", 12.0, 0.72, 0, 8);
            insertActivityRaw(db, targetUser, "Food", "Fruits & Vegetables", 1.0, 0.55, 0, 12);
            insertActivityRaw(db, targetUser, "Energy", "Electricity", 3.0, 2.10, 0, 15);
            insertActivityRaw(db, targetUser, "Waste", "Paper & Cardboard", 1.5, 0.45, 0, 18);
            insertActivityRaw(db, targetUser, "Food", "Low-Impact Meat", 1.0, 1.40, 0, 19);

            insertActivityRaw(db, targetUser, "Transport", "Jeepney", 8.5, 0.95, 1, 8);
            insertActivityRaw(db, targetUser, "Food", "Medium-Impact Meat", 1.0, 2.60, 1, 12);
            insertActivityRaw(db, targetUser, "Energy", "Electricity", 2.5, 1.75, 1, 16);
            insertActivityRaw(db, targetUser, "Shopping", "Household Products", 1.0, 0.30, 1, 18);

            insertActivityRaw(db, targetUser, "Transport", "Car", 15.0, 1.80, 2, 7);
            insertActivityRaw(db, targetUser, "Food", "Seafood", 1.0, 1.20, 2, 13);
            insertActivityRaw(db, targetUser, "Energy", "Electricity", 2.0, 1.40, 2, 21);
            insertActivityRaw(db, targetUser, "Waste", "Food Waste", 2.0, 0.60, 2, 22);

            insertActivityRaw(db, targetUser, "Transport", "Tricycle", 2.0, 0.00, 3, 9);
            insertActivityRaw(db, targetUser, "Food", "Legumes & Plant-Based", 1.0, 0.50, 3, 12);
            insertActivityRaw(db, targetUser, "Energy", "Electricity", 3.5, 2.45, 3, 17);
            insertActivityRaw(db, targetUser, "Food", "High-Impact Meat", 1.0, 3.80, 3, 20);

            insertActivityRaw(db, targetUser, "Transport", "Jeepney", 6.0, 0.70, 4, 8);
            insertActivityRaw(db, targetUser, "Food", "Medium-Impact Meat", 1.0, 1.30, 4, 12);
            insertActivityRaw(db, targetUser, "Shopping", "Clothing & Footwear", 1.0, 3.50, 4, 16);
            insertActivityRaw(db, targetUser, "Waste", "Mixed/General Waste", 1.5, 1.20, 4, 21);

            insertActivityRaw(db, targetUser, "Transport", "Bus", 10.0, 0.60, 5, 8);
            insertActivityRaw(db, targetUser, "Food", "Grains & Staples", 1.0, 0.40, 5, 12);
            insertActivityRaw(db, targetUser, "Energy", "Electricity", 3.0, 2.10, 5, 15);
            insertActivityRaw(db, targetUser, "Food", "Seafood", 1.0, 1.25, 5, 19);

            insertActivityRaw(db, targetUser, "Transport", "Motorcycle", 7.0, 0.85, 6, 9);
            insertActivityRaw(db, targetUser, "Food", "High-Impact Meat", 1.0, 3.60, 6, 13);
            insertActivityRaw(db, targetUser, "Energy", "Electricity", 2.8, 1.95, 6, 17);
            insertActivityRaw(db, targetUser, "Waste", "Plastic", 1.0, 0.90, 6, 20);

            insertActivityRaw(db, targetUser, "Transport", "UV/Van", 12.0, 1.35, 7, 8);
            insertActivityRaw(db, targetUser, "Food", "Fruits & Vegetables", 1.0, 0.50, 7, 19);
            insertActivityRaw(db, targetUser, "Energy", "Electricity", 3.2, 2.25, 7, 21);

            for (int day = 8; day <= 14; day++) {
                insertActivityRaw(db, targetUser, "Transport", "Car", 14.0, 2.65, day, 8);
                insertActivityRaw(db, targetUser, "Food", "Low-Impact Meat", 1.0, 1.45, day, 12);
                insertActivityRaw(db, targetUser, "Energy", "Electricity", 4.0, 2.80, day, 15);
                insertActivityRaw(db, targetUser, "Waste", "Food Waste", 1.2, 0.95, day, 20);
            }

            for (int day = 15; day <= 21; day++) {
                insertActivityRaw(db, targetUser, "Transport", "Taxi", 18.0, 3.40, day, 8);
                insertActivityRaw(db, targetUser, "Food", "High-Impact Meat", 1.0, 4.10, day, 13);
                insertActivityRaw(db, targetUser, "Energy", "Electricity", 4.5, 3.15, day, 18);
                if (day % 2 == 0) {
                    insertActivityRaw(db, targetUser, "Shopping", "Personal Care", 3.0, 2.40, day, 16);
                }
            }

            for (int day = 22; day <= 29; day++) {
                insertActivityRaw(db, targetUser, "Transport", "Car", 20.0, 4.20, day, 8);
                insertActivityRaw(db, targetUser, "Food", "Processed & Packaged", 1.0, 3.90, day, 12);
                insertActivityRaw(db, targetUser, "Energy", "Electricity", 5.5, 3.85, day, 16);
                insertActivityRaw(db, targetUser, "Waste", "Mixed/General Waste", 2.5, 2.10, day, 21);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }

        long now = System.currentTimeMillis();

        ContentValues activeGoal = new ContentValues();
        activeGoal.put(DatabaseHelper.COLUMN_GOAL_USERNAME, targetUser);
        activeGoal.put(DatabaseHelper.COLUMN_GOAL_TITLE, "Walk or Cycle for Short Trips");
        activeGoal.put(DatabaseHelper.COLUMN_GOAL_DESC, "Reduce transport footprint by 25% this week");
        activeGoal.put(DatabaseHelper.COLUMN_GOAL_TARGET, 25);
        activeGoal.put(DatabaseHelper.COLUMN_GOAL_PROGRESS, 60);
        activeGoal.put(DatabaseHelper.COLUMN_GOAL_PERIOD, "Weekly");
        activeGoal.put(DatabaseHelper.COLUMN_GOAL_CATEGORY, "Transport");
        activeGoal.put(DatabaseHelper.COLUMN_GOAL_COMPLETED, 0);
        activeGoal.put(DatabaseHelper.COLUMN_GOAL_CREATED_AT, now - (2L * 24 * 60 * 60 * 1000));
        db.insert(DatabaseHelper.TABLE_GOALS, null, activeGoal);

        ContentValues compGoal = new ContentValues();
        compGoal.put(DatabaseHelper.COLUMN_GOAL_USERNAME, targetUser);
        compGoal.put(DatabaseHelper.COLUMN_GOAL_TITLE, "Eat Plant-Based Weekday Lunches");
        compGoal.put(DatabaseHelper.COLUMN_GOAL_DESC, "Reduce food footprint by 20% this week");
        compGoal.put(DatabaseHelper.COLUMN_GOAL_TARGET, 20);
        compGoal.put(DatabaseHelper.COLUMN_GOAL_PROGRESS, 100);
        compGoal.put(DatabaseHelper.COLUMN_GOAL_PERIOD, "Weekly");
        compGoal.put(DatabaseHelper.COLUMN_GOAL_CATEGORY, "Food");
        compGoal.put(DatabaseHelper.COLUMN_GOAL_COMPLETED, 1);
        compGoal.put(DatabaseHelper.COLUMN_GOAL_CREATED_AT, now - (5L * 24 * 60 * 60 * 1000));
        db.insert(DatabaseHelper.TABLE_GOALS, null, compGoal);

        ContentValues unfGoal = new ContentValues();
        unfGoal.put(DatabaseHelper.COLUMN_GOAL_USERNAME, targetUser);
        unfGoal.put(DatabaseHelper.COLUMN_GOAL_TITLE, "Cut Down Aircon to 2 Hours Daily");
        unfGoal.put(DatabaseHelper.COLUMN_GOAL_DESC, "Reduce energy footprint by 30% this week");
        unfGoal.put(DatabaseHelper.COLUMN_GOAL_TARGET, 30);
        unfGoal.put(DatabaseHelper.COLUMN_GOAL_PROGRESS, 15);
        unfGoal.put(DatabaseHelper.COLUMN_GOAL_PERIOD, "Weekly");
        unfGoal.put(DatabaseHelper.COLUMN_GOAL_CATEGORY, "Energy");
        unfGoal.put(DatabaseHelper.COLUMN_GOAL_COMPLETED, 0);
        unfGoal.put(DatabaseHelper.COLUMN_GOAL_CREATED_AT, now - (9L * 24 * 60 * 60 * 1000));
        db.insert(DatabaseHelper.TABLE_GOALS, null, unfGoal);
    }

    private static void insertActivityRaw(SQLiteDatabase db, String username, String type, String subtype, double value, double co2e, int daysAgo, int hourOfDay) {
        String sql = "INSERT INTO " + DatabaseHelper.TABLE_ACTIVITY + " (" +
                DatabaseHelper.COLUMN_USERNAME + ", " +
                DatabaseHelper.COLUMN_TYPE + ", " +
                DatabaseHelper.COLUMN_SUBTYPE + ", " +
                DatabaseHelper.COLUMN_VALUE + ", " +
                DatabaseHelper.COLUMN_CO2E + ", " +
                DatabaseHelper.COLUMN_TIMESTAMP + ") VALUES (?, ?, ?, ?, ?, datetime('now', 'localtime', '-" + daysAgo + " days', '+" + (hourOfDay - 12) + " hours'))";
        db.execSQL(sql, new Object[]{username, type, subtype, value, co2e});
    }
}