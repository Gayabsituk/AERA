package com.example.aera;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SetGoalFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private Spinner spinnerPeriod, spinnerCategory;
    private EditText etTarget, etTitle;
    private ImageView ivPeriodArrow, ivCategoryArrow;
    private TextView tvHeaderTitle;

    private int goalId = -1; // -1 means creating a new goal, otherwise it's an edit

    // Helper method to create a fragment instance with Goal data
    public static SetGoalFragment newInstance(int id, String title, int target, String period, String category) {
        SetGoalFragment fragment = new SetGoalFragment();
        Bundle args = new Bundle();
        args.putInt("id", id);
        args.putString("title", title);
        args.putInt("target", target);
        args.putString("period", period);
        args.putString("category", category);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_set_goal, container, false);
        dbHelper = new DatabaseHelper(requireContext());

        // Initialize Views
        spinnerPeriod = view.findViewById(R.id.spinner_goal_period);
        spinnerCategory = view.findViewById(R.id.spinner_goal_category);
        etTarget = view.findViewById(R.id.et_target_reduction);
        etTitle = view.findViewById(R.id.et_goal_title);
        tvHeaderTitle = view.findViewById(R.id.tv_set_goal_title);

        ivPeriodArrow = view.findViewById(R.id.iv_period_arrow);
        ivCategoryArrow = view.findViewById(R.id.iv_category_arrow);

        spinnerPeriod.setPopupBackgroundResource(R.drawable.bg_rounded_dropdown);
        spinnerCategory.setPopupBackgroundResource(R.drawable.bg_rounded_dropdown);

        // Setup Spinners
        String[] periods = {"Weekly", "Monthly", "Yearly"};
        String[] categories = {"Overall Footprint", "Transport", "Energy", "Food", "Shopping", "Waste"};

        ArrayAdapter<String> periodAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, periods);
        periodAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerPeriod.setAdapter(periodAdapter);

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, categories);
        categoryAdapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinnerCategory.setAdapter(categoryAdapter);

        setupSpinnerArrowBehavior(spinnerPeriod, ivPeriodArrow);
        setupSpinnerArrowBehavior(spinnerCategory, ivCategoryArrow);

        // CHECK FOR EXISTING DATA (Edit Mode)
        if (getArguments() != null) {
            goalId = getArguments().getInt("id", -1);
            if (goalId != -1) {
                tvHeaderTitle.setText("Edit Goal"); // Change header text
                etTitle.setText(getArguments().getString("title", ""));
                etTarget.setText(String.valueOf(getArguments().getInt("target", 0)));

                // Pre-select the Spinners
                spinnerPeriod.setSelection(getSpinnerIndex(spinnerPeriod, getArguments().getString("period", "")));
                spinnerCategory.setSelection(getSpinnerIndex(spinnerCategory, getArguments().getString("category", "")));
            }
        }

        // Button Click Listeners
        view.findViewById(R.id.btn_back).setOnClickListener(v -> getParentFragmentManager().popBackStack());

        // Instead of saving directly, we call confirmSave()
        view.findViewById(R.id.btn_save_goal).setOnClickListener(v -> confirmSave());

        return view;
    }

    private void setupSpinnerArrowBehavior(Spinner spinner, ImageView arrowIcon) {
        spinner.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                arrowIcon.setImageResource(R.drawable.ic_chevron_up);
            }
            return false;
        });

        spinner.getViewTreeObserver().addOnWindowFocusChangeListener(hasFocus -> {
            if (hasFocus) {
                arrowIcon.setImageResource(R.drawable.ic_chevron_down);
            }
        });
    }

    // Helper to find the correct dropdown item
    private int getSpinnerIndex(Spinner spinner, String value) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(value)) {
                return i;
            }
        }
        return 0;
    }

    private void confirmSave() {
        // Validate inputs first
        String title = etTitle.getText().toString().trim();
        String targetStr = etTarget.getText().toString().trim();

        if (title.isEmpty()) {
            etTitle.setError("Required");
            etTitle.requestFocus();
            return;
        }

        if (targetStr.isEmpty()) {
            etTarget.setError("Required");
            etTarget.requestFocus();
            return;
        }

        // 1. Create the dialog object
        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle(goalId == -1 ? "Save Goal" : "Save Changes")
                .setMessage(goalId == -1 ? "Are you sure you want to create this goal?" : "Are you sure you want to save these changes?")
                .setPositiveButton("Yes", (d, which) -> executeSave(title, targetStr))
                // NEW: Changed 'null' to a listener that goes back to the previous page
                .setNegativeButton("Cancel", (d, which) -> getParentFragmentManager().popBackStack())
                .create();

        // 2. Apply the rounded corner background
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.bg_rounded_dialog);
        }

        // 3. You MUST call show() before attempting to change button colors
        dialog.show();

        // 4. Change the button text colors
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#2E7D32")); // Green "Yes"
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#D32F2F")); // Red "Cancel"
    }

    private void executeSave(String title, String targetStr) {
        int target = Integer.parseInt(targetStr);
        String period = spinnerPeriod.getSelectedItem().toString();
        String category = spinnerCategory.getSelectedItem().toString();
        String desc = "Reduce " + category.toLowerCase() + " by " + target + "% this " + period.toLowerCase().replace("ly", "");

        if (goalId == -1) {
            // New Goal
            dbHelper.addGoal(title, desc, target, period, category);
            Toast.makeText(requireContext(), "Goal Set!", Toast.LENGTH_SHORT).show();
        } else {
            // Edit Existing Goal
            dbHelper.updateGoal(goalId, title, desc, target, period, category);
            Toast.makeText(requireContext(), "Goal Updated!", Toast.LENGTH_SHORT).show();
        }

        getParentFragmentManager().popBackStack();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() instanceof Aera) {
            ((Aera) getActivity()).setBottomNavigationVisibility(true);
        }
    }
}