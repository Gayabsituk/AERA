package com.example.aera;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class GoalsFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private RecyclerView rvActiveGoals, rvCompletedGoals, rvUnfinishedGoals;

    private ActiveGoalAdapter activeAdapter;
    private ActiveGoalAdapter completedAdapter;
    private UnfinishedGoalAdapter unfinishedAdapter;

    private TextView tvEmptyTitle, tvEmptyDesc;
    private View layoutEmptyState, btnEmptyAddGoal;

    private TextView btnOptionActive, btnOptionCompleted, btnOptionNotFinished;
    private View slidingIndicator;
    private int currentTab = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_goals, container, false);

        if (getActivity() instanceof Aera) {
            ((Aera) getActivity()).setBottomNavigationVisibility(true);
            ((Aera) getActivity()).updateBottomNavSelection(R.id.nav_goals);
        }

        try {
            dbHelper = new DatabaseHelper(requireContext());

            layoutEmptyState = view.findViewById(R.id.layout_empty_state);
            tvEmptyTitle = view.findViewById(R.id.tv_empty_title);
            tvEmptyDesc = view.findViewById(R.id.tv_empty_desc);
            btnEmptyAddGoal = view.findViewById(R.id.btn_empty_add_goal);

            btnOptionActive = view.findViewById(R.id.btnOptionActive);
            btnOptionCompleted = view.findViewById(R.id.btnOptionCompleted);
            btnOptionNotFinished = view.findViewById(R.id.btnOptionNotFinished);
            slidingIndicator = view.findViewById(R.id.slidingIndicator);

            // 1. Setup Active Goals
            rvActiveGoals = view.findViewById(R.id.rv_active_goals);
            if (rvActiveGoals != null) {
                rvActiveGoals.setLayoutManager(new LinearLayoutManager(requireContext()));
                activeAdapter = new ActiveGoalAdapter(goal -> openSetGoal(true, goal));
                rvActiveGoals.setAdapter(activeAdapter);
            }

            // 2. Setup Completed Goals
            rvCompletedGoals = view.findViewById(R.id.rv_completed_goals);
            if (rvCompletedGoals != null) {
                rvCompletedGoals.setLayoutManager(new LinearLayoutManager(requireContext()));
                completedAdapter = new ActiveGoalAdapter(goal -> openSetGoal(true, goal));
                rvCompletedGoals.setAdapter(completedAdapter);
            }

            // 3. Setup Unfinished Goals
            rvUnfinishedGoals = view.findViewById(R.id.rv_unfinished_goals);
            if (rvUnfinishedGoals != null) {
                rvUnfinishedGoals.setLayoutManager(new LinearLayoutManager(requireContext()));
                // If they click "Restart", open SetGoalFragment in Edit Mode
                unfinishedAdapter = new UnfinishedGoalAdapter(goal -> openSetGoal(true, goal));
                rvUnfinishedGoals.setAdapter(unfinishedAdapter);
            }

            view.findViewById(R.id.btn_add_goal_top).setOnClickListener(v -> openSetGoal(false, null));
            btnEmptyAddGoal.setOnClickListener(v -> openSetGoal(false, null));

            btnOptionActive.setOnClickListener(v -> selectTab(0));
            btnOptionCompleted.setOnClickListener(v -> selectTab(1));
            btnOptionNotFinished.setOnClickListener(v -> selectTab(2));

            if (slidingIndicator != null) {
                slidingIndicator.post(() -> updateIndicatorPosition(currentTab, false));
            }

            refreshUI();

        } catch (Exception e) {
            Log.e("GoalsFragment", "Error: " + e.getMessage());
        }

        return view;
    }

    private void updateIndicatorPosition(int tabIndex, boolean animate) {
        View targetView = btnOptionActive;
        if (tabIndex == 1) targetView = btnOptionCompleted;
        else if (tabIndex == 2) targetView = btnOptionNotFinished;

        if (targetView != null && slidingIndicator != null) {
            ViewGroup.LayoutParams params = slidingIndicator.getLayoutParams();
            params.width = targetView.getWidth();
            slidingIndicator.setLayoutParams(params);

            if (animate) {
                slidingIndicator.animate().x(targetView.getX()).setDuration(200).start();
            } else {
                slidingIndicator.setX(targetView.getX());
            }
        }
    }

    private void selectTab(int tabIndex) {
        if (currentTab == tabIndex) {
            updateIndicatorPosition(tabIndex, false);
            return;
        }
        currentTab = tabIndex;
        updateIndicatorPosition(tabIndex, true);

        btnOptionActive.setTextColor(tabIndex == 0 ? Color.parseColor("#2D6A4F") : Color.parseColor("#6B7280"));
        btnOptionCompleted.setTextColor(tabIndex == 1 ? Color.parseColor("#2D6A4F") : Color.parseColor("#6B7280"));
        btnOptionNotFinished.setTextColor(tabIndex == 2 ? Color.parseColor("#2D6A4F") : Color.parseColor("#6B7280"));

        refreshUI();
    }

    private void refreshUI() {
        try {
            if (currentTab == 0) {
                // --- ACTIVE GOALS ---
                if (rvCompletedGoals != null) rvCompletedGoals.setVisibility(View.GONE);
                if (rvUnfinishedGoals != null) rvUnfinishedGoals.setVisibility(View.GONE);

                // We must filter out unfinished goals from the active list so they don't show twice
                List<Goal> allActive = dbHelper.getAllActiveGoals();
                List<Goal> unfinishedList = dbHelper.getUnfinishedGoals();

                // Remove expired items from the active tab view
                for (Goal expired : unfinishedList) {
                    allActive.removeIf(goal -> goal.getId() == expired.getId());
                }

                if (allActive != null && !allActive.isEmpty()) {
                    if (rvActiveGoals != null) rvActiveGoals.setVisibility(View.VISIBLE);
                    layoutEmptyState.setVisibility(View.GONE);
                    activeAdapter.updateList(allActive);
                } else {
                    if (rvActiveGoals != null) rvActiveGoals.setVisibility(View.GONE);
                    layoutEmptyState.setVisibility(View.VISIBLE);
                    tvEmptyTitle.setText("No Active Goals");
                    tvEmptyDesc.setText("Set a goal to track your carbon reduction and build better habits.");
                    btnEmptyAddGoal.setVisibility(View.VISIBLE);
                }

            } else if (currentTab == 1) {
                // --- COMPLETED GOALS ---
                if (rvActiveGoals != null) rvActiveGoals.setVisibility(View.GONE);
                if (rvUnfinishedGoals != null) rvUnfinishedGoals.setVisibility(View.GONE);

                List<Goal> completedGoals = dbHelper.getCompletedGoals();

                if (completedGoals != null && !completedGoals.isEmpty()) {
                    if (rvCompletedGoals != null) rvCompletedGoals.setVisibility(View.VISIBLE);
                    layoutEmptyState.setVisibility(View.GONE);
                    completedAdapter.updateList(completedGoals);
                } else {
                    if (rvCompletedGoals != null) rvCompletedGoals.setVisibility(View.GONE);
                    layoutEmptyState.setVisibility(View.VISIBLE);
                    tvEmptyTitle.setText("No Completed Goals");
                    tvEmptyDesc.setText("Your finished goals will appear here. Keep pushing towards your active targets!");
                    btnEmptyAddGoal.setVisibility(View.GONE);
                }

            } else if (currentTab == 2) {
                // --- NOT FINISHED GOALS ---
                if (rvActiveGoals != null) rvActiveGoals.setVisibility(View.GONE);
                if (rvCompletedGoals != null) rvCompletedGoals.setVisibility(View.GONE);

                List<Goal> unfinishedList = dbHelper.getUnfinishedGoals();

                if (unfinishedList != null && !unfinishedList.isEmpty()) {
                    if (rvUnfinishedGoals != null) rvUnfinishedGoals.setVisibility(View.VISIBLE);
                    layoutEmptyState.setVisibility(View.GONE);
                    unfinishedAdapter.updateList(unfinishedList);
                } else {
                    if (rvUnfinishedGoals != null) rvUnfinishedGoals.setVisibility(View.GONE);
                    layoutEmptyState.setVisibility(View.VISIBLE);
                    tvEmptyTitle.setText("No Unfinished Goals");
                    tvEmptyDesc.setText("Goals that expired before completion will appear here.");
                    btnEmptyAddGoal.setVisibility(View.GONE);
                }
            }
        } catch (Exception e) {
            Log.e("GoalsFragment", "Error loading goals: " + e.getMessage());
        }
    }

    private void openSetGoal(boolean isEditMode, @Nullable Goal goalToEdit) {
        if (getParentFragmentManager() != null && getView() != null) {
            SetGoalFragment fragment;

            if (isEditMode && goalToEdit != null) {
                fragment = SetGoalFragment.newInstance(
                        goalToEdit.getId(),
                        goalToEdit.getTitle(),
                        goalToEdit.getTargetPercentage(),
                        goalToEdit.getPeriod(),
                        goalToEdit.getCategory()
                );
            } else {
                fragment = new SetGoalFragment();
            }

            int containerId = ((ViewGroup) getView().getParent()).getId();

            getParentFragmentManager().beginTransaction()
                    .replace(containerId, fragment)
                    .addToBackStack(null)
                    .commit();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() instanceof Aera) {
            ((Aera) getActivity()).setBottomNavigationVisibility(true);
            ((Aera) getActivity()).updateBottomNavSelection(R.id.nav_goals);
        }
        if (slidingIndicator != null) {
            slidingIndicator.post(() -> updateIndicatorPosition(currentTab, false));
        }
        refreshUI();
    }
}