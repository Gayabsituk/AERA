package com.example.aera;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;

import android.graphics.Typeface;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class DayFragment extends Fragment {

    private PieChart pieChart;
    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_day, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dbHelper = new DatabaseHelper(requireContext());
        pieChart = view.findViewById(R.id.pieChart);
    }

    @Override
    public void onResume() {
        super.onResume();
        // Forces real-time refresh whenever user returns to this screen
        if (pieChart != null) {
            pieChart.post(this::setupPieChart);
        }
    }

    private void setupPieChart() {
        if (dbHelper == null || pieChart == null) return;

        // Establish strict Philippine Standard Time (PST / UTC+8) calendar context
        TimeZone phTimeZone = TimeZone.getTimeZone("Asia/Manila");
        Calendar phCalendar = Calendar.getInstance(phTimeZone);
        int currentHour = phCalendar.get(Calendar.HOUR_OF_DAY);
        int currentMinute = phCalendar.get(Calendar.MINUTE);

        // (Optional lifecycle hook) Daily boundary check for Philippine 12:00 AM roll-over
        boolean isStartOfNewPhilippineDay = (currentHour == 0 && currentMinute == 0);

        // Fetch real daily data based on Philippine time boundaries
        List<PieEntry> entries = dbHelper.getCategoryBreakdown("day");
        double totalToday = 0;
        for (PieEntry entry : entries) totalToday += entry.getValue();

        // hole size and text radius
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.WHITE);
        pieChart.setHoleRadius(82f);
        pieChart.setTransparentCircleRadius(0f);

        // Center Text as per image
        String centerText = String.format(Locale.getDefault(), "Emissions\n%.2f kg", totalToday);
        SpannableString s = new SpannableString(centerText);
        s.setSpan(new RelativeSizeSpan(0.8f), 0, 9, 0); // "Emissions"
        s.setSpan(new ForegroundColorSpan(Color.parseColor("#6B7280")), 0, 9, 0);
        s.setSpan(new StyleSpan(Typeface.BOLD), 10, centerText.length(), 0); // Amount
        s.setSpan(new RelativeSizeSpan(1.4f), 10, centerText.length(), 0);
        s.setSpan(new ForegroundColorSpan(Color.parseColor("#1F2937")), 10, centerText.length(), 0);

        pieChart.setCenterText(s);

        // hide chart descriptions and legends
        pieChart.getDescription().setEnabled(false);
        pieChart.getLegend().setEnabled(false);
        pieChart.setRotationEnabled(false);
        pieChart.setDrawEntryLabels(false); // REMOVE TEXT FROM SLICES

        if (entries.isEmpty()) {
            ArrayList<PieEntry> emptyEntries = new ArrayList<>();
            emptyEntries.add(new PieEntry(1f, ""));
            PieDataSet dataSet = new PieDataSet(emptyEntries, "");
            dataSet.setColors(Color.parseColor("#F3F4F6"));
            dataSet.setDrawValues(false);
            pieChart.setData(new PieData(dataSet));
        } else {
            PieDataSet dataSet = new PieDataSet(entries, "");

            // Map colors to specific categories dynamically
            List<Integer> colors = new ArrayList<>();
            for (PieEntry entry : entries) {
                String label = entry.getLabel();
                if ("Transport".equals(label)) colors.add(Color.parseColor("#264F36"));
                else if ("Energy".equals(label)) colors.add(Color.parseColor("#D4734B"));
                else if ("Food".equals(label)) colors.add(Color.parseColor("#A06B9A"));
                else if ("Shopping".equals(label)) colors.add(Color.parseColor("#6BAABC"));
                else if ("Waste".equals(label)) colors.add(Color.parseColor("#D4CF4B"));
                else colors.add(Color.GRAY);
            }

            dataSet.setColors(colors);
            dataSet.setDrawValues(false);
            pieChart.setData(new PieData(dataSet));
        }

        pieChart.notifyDataSetChanged();
        pieChart.invalidate();

        if (getView() != null) {
            updateCategoryList(entries, totalToday);
        }
    }

    private void updateCategoryList(List<PieEntry> entries, double total) {
        View layoutTransport = getView().findViewById(R.id.itemTransport);
        View layoutEnergy = getView().findViewById(R.id.itemEnergy);
        View layoutFood = getView().findViewById(R.id.itemFood);
        View layoutShopping = getView().findViewById(R.id.itemShopping);
        View layoutWaste = getView().findViewById(R.id.itemWaste);

        setupCategoryItem(layoutTransport, "Transport", "#264F36", entries, total);
        setupCategoryItem(layoutEnergy, "Energy", "#D4734B", entries, total);
        setupCategoryItem(layoutFood, "Food", "#A06B9A", entries, total);
        setupCategoryItem(layoutShopping, "Shopping", "#6BAABC", entries, total);
        setupCategoryItem(layoutWaste, "Waste", "#D4CF4B", entries, total);
    }

    private void setupCategoryItem(View view, String name, String color, List<PieEntry> entries, double total) {
        if (view == null) return;

        View dot = view.findViewById(R.id.dotCategory);
        TextView tvName = view.findViewById(R.id.tvCategoryName);
        TextView tvKg = view.findViewById(R.id.tvCategoryKg);
        TextView tvPercent = view.findViewById(R.id.tvCategoryPercent);

        if (dot != null) dot.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(color)));
        if (tvName != null) tvName.setText(name);

        float val = 0;
        for (PieEntry e : entries) {
            if (name.equals(e.getLabel())) {
                val = e.getValue();
                break;
            }
        }

        if (tvKg != null) tvKg.setText(String.format(Locale.getDefault(), "%.1f kg", val));
        int percent = total == 0 ? 0 : (int) ((val / total) * 100);
        if (tvPercent != null) tvPercent.setText(percent + "%");
    }
}