package com.example.aera;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import java.util.ArrayList;
import java.util.List;

public class UnfinishedGoalAdapter extends RecyclerView.Adapter<UnfinishedGoalAdapter.GoalViewHolder> {

    private List<Goal> goalList = new ArrayList<>();
    private final OnGoalRestartListener restartListener;

    public interface OnGoalRestartListener {
        void onRestart(Goal goal);
    }

    public UnfinishedGoalAdapter(OnGoalRestartListener restartListener) {
        this.restartListener = restartListener;
    }

    public void updateList(List<Goal> newList) {
        goalList.clear();
        goalList.addAll(newList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public GoalViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_goal_unfinished, parent, false);
        return new GoalViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GoalViewHolder holder, int position) {
        Goal goal = goalList.get(position);

        holder.tvTitle.setText(goal.getTitle());
        holder.tvCategory.setText("Category: " + goal.getCategory());
        holder.tvDescription.setText(goal.getDescription());

        // Ensure progress reflects what they achieved before it expired
        holder.progressBar.setProgress(goal.getProgressPercentage());
        holder.tvPercentage.setText(goal.getProgressPercentage() + "% completed");

        // When "Restart" is clicked, trigger the listener to open SetGoalFragment in Edit Mode
        holder.tvAction.setOnClickListener(v -> restartListener.onRestart(goal));
    }

    @Override
    public int getItemCount() {
        return goalList.size();
    }

    static class GoalViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvCategory, tvDescription, tvAction, tvPercentage;
        LinearProgressIndicator progressBar;

        public GoalViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvCategory = itemView.findViewById(R.id.tv_category);
            tvDescription = itemView.findViewById(R.id.tv_description);
            tvAction = itemView.findViewById(R.id.tv_action); // The "Restart" button
            tvPercentage = itemView.findViewById(R.id.tv_percentage);
            progressBar = itemView.findViewById(R.id.progress_bar);
        }
    }
}