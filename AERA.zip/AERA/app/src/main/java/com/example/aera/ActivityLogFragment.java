package com.example.aera;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class ActivityLogFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private ActivityAdapter adapter;
    private RecyclerView rvActivities;
    private View layoutEmptyState;

    private static final String PREFS_NAME = "AeraPrefs";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_log, container, false);

        // Show Bottom Nav and sync icon
        ((Aera) requireActivity()).setBottomNavigationVisibility(true);
        ((Aera) requireActivity()).updateBottomNavSelection(R.id.nav_activity);

        dbHelper = new DatabaseHelper(requireContext());

        // Initialize views
        rvActivities = view.findViewById(R.id.rv_activities);
        layoutEmptyState = view.findViewById(R.id.layout_empty_state);

        rvActivities.setLayoutManager(new LinearLayoutManager(requireContext()));

        adapter = new ActivityAdapter(new ArrayList<>());
        rvActivities.setAdapter(adapter);

        MaterialButton fabAddActivity = view.findViewById(R.id.fab_add_activity);
        fabAddActivity.setOnClickListener(v -> {
            ((Aera) requireActivity()).switchFragment(new LogActivityFragment(), true);
        });

        checkAndRefreshDailyActivityLog();
        return view;
    }

    private void checkAndRefreshDailyActivityLog() {
        try {
            SharedPreferences prefs = requireActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String lastLogDate = prefs.getString("ACTIVITY_LOG_LAST_DATE", "");

            // Enforce strict Philippine Standard Time (Asia/Manila) for daily rollover at 12:00 AM
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            sdf.setTimeZone(TimeZone.getTimeZone("Asia/Manila"));
            String currentDate = sdf.format(new Date());

            if (!currentDate.equals(lastLogDate)) {
                // A new day in the Philippines has started; update the tracking date
                prefs.edit().putString("ACTIVITY_LOG_LAST_DATE", currentDate).apply();
            }

            loadActivities();
        } catch (Exception e) {
            loadActivities();
        }
    }

    private void loadActivities() {
        if (dbHelper != null && adapter != null) {
            List<?> activities = dbHelper.getAllActivities();

            if (activities == null || activities.isEmpty()) {
                // Show Empty State, Hide RecyclerView
                if (layoutEmptyState != null) layoutEmptyState.setVisibility(View.VISIBLE);
                if (rvActivities != null) rvActivities.setVisibility(View.GONE);
            } else {
                // Hide Empty State, Show RecyclerView and update adapter
                if (layoutEmptyState != null) layoutEmptyState.setVisibility(View.GONE);
                if (rvActivities != null) rvActivities.setVisibility(View.VISIBLE);
                adapter.updateList(dbHelper.getAllActivities());
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Triggers daily check and real-time refresh whenever user resumes this screen
        checkAndRefreshDailyActivityLog();
    }
}