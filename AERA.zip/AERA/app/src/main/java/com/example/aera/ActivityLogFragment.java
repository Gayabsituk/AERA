package com.example.aera;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class ActivityLogFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private ActivityAdapter adapter;
    private RecyclerView rvActivities;
    private View layoutEmptyState;
    private ChipGroup chipGroupFilter;
    private String currentFilter = "All";
    private List<ActivityEntry> allActivities = new ArrayList<>();

    private static final String PREFS_NAME = "AeraPrefs";
    private static final String KEY_LAST_LOG_DATE = "ACTIVITY_LOG_LAST_DATE";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_log, container, false);

        try {
            ((Aera) requireActivity()).setBottomNavigationVisibility(true);
            ((Aera) requireActivity()).updateBottomNavSelection(R.id.nav_activity);
        } catch (Exception e) {}

        dbHelper = new DatabaseHelper(requireContext());

        rvActivities = view.findViewById(R.id.rv_activities);
        layoutEmptyState = view.findViewById(R.id.layout_empty_state);
        chipGroupFilter = view.findViewById(R.id.chipGroupFilter);
        MaterialButton fabAddActivity = view.findViewById(R.id.fab_add_activity);

        rvActivities.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ActivityAdapter(new ArrayList<>());
        rvActivities.setAdapter(adapter);

        fabAddActivity.setOnClickListener(v -> {
            LogActivityFragment addFragment = new LogActivityFragment();
            Bundle args = new Bundle();
            args.putInt("EDIT_ID", -1); // Explicitly declare this is NOT an edit
            addFragment.setArguments(args);

            requireActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, addFragment)
                    .addToBackStack(null)
                    .commit();
        });

        // Filter Logic
        chipGroupFilter.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int id = checkedIds.get(0);

            if (id == R.id.chip_filter_all) currentFilter = "All";
            else if (id == R.id.chip_filter_transport) currentFilter = "Transport";
            else if (id == R.id.chip_filter_energy) currentFilter = "Energy";
            else if (id == R.id.chip_filter_food) currentFilter = "Food";
            else if (id == R.id.chip_filter_shopping) currentFilter = "Shopping";
            else if (id == R.id.chip_filter_waste) currentFilter = "Waste";

            applyFilter();
        });

        checkAndRefreshDailyActivityLog();
        return view;
    }

    private void checkAndRefreshDailyActivityLog() {
        try {
            SharedPreferences prefs = requireActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String lastLogDate = prefs.getString(KEY_LAST_LOG_DATE, "");

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            sdf.setTimeZone(TimeZone.getTimeZone("Asia/Manila"));
            String currentPHDate = sdf.format(new Date());

            if (!currentPHDate.equals(lastLogDate)) {
                prefs.edit().putString(KEY_LAST_LOG_DATE, currentPHDate).apply();
            }
            loadActivities();
        } catch (Exception e) {
            loadActivities();
        }
    }

    private void loadActivities() {
        if (dbHelper != null && adapter != null) {
            allActivities = dbHelper.getAllActivities();
            applyFilter();
        }
    }

    private void applyFilter() {
        List<ActivityEntry> filteredList = new ArrayList<>();
        for (ActivityEntry item : allActivities) {
            if (currentFilter.equals("All") || (item.getType() != null && item.getType().equalsIgnoreCase(currentFilter))) {
                filteredList.add(item);
            }
        }

        if (filteredList.isEmpty()) {
            layoutEmptyState.setVisibility(View.VISIBLE);
            rvActivities.setVisibility(View.GONE);
        } else {
            layoutEmptyState.setVisibility(View.GONE);
            rvActivities.setVisibility(View.VISIBLE);
            adapter.updateList(filteredList);
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        // Ensure filter resets to "All" whenever this Fragment is revealed (from a popBackStack)
        if (chipGroupFilter != null) {
            chipGroupFilter.check(R.id.chip_filter_all);
            currentFilter = "All";
        }

        checkAndRefreshDailyActivityLog();
    }
}