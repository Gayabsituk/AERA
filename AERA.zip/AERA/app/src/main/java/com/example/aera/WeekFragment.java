package com.example.aera;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class WeekFragment extends Fragment {

    private BarChart barChart;
    private PieChart weekPieChart;
    private TextView tvTotalWeekEmissions;
    private TextView tvWeekComparison;
    private DatabaseHelper dbHelper;

    private static final float HIGH_EMISSION_THRESHOLD = 5.0f;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_week, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dbHelper = new DatabaseHelper(requireContext());

        barChart = view.findViewById(R.id.barChart);
        weekPieChart = view.findViewById(R.id.weekPieChart);
        tvTotalWeekEmissions = view.findViewById(R.id.tvTotalWeekEmissions);
        tvWeekComparison = view.findViewById(R.id.tvWeekComparison);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadRealData();
    }

    private void loadRealData() {
        if (dbHelper == null) return;

        TimeZone phTimeZone = TimeZone.getTimeZone("Asia/Manila");
        Calendar phCalendar = Calendar.getInstance(phTimeZone);
        int dayOfWeek = phCalendar.get(Calendar.DAY_OF_WEEK); // Sunday = 1, Monday = 2, etc.
        int todayIndex = dayOfWeek - 1; // 0 for Sunday, 2 for Tuesday, etc.

        // Get the last 7 days from the database (index 6 is today)
        float[] rawDailyTotals = dbHelper.getDailyTotals(7);

        // Map the rolling 7 days to the current fixed Sun-Sat week
        float[] currentWeekTotals = new float[7]; // Defaults to 0.0f for future days
        for (int i = 0; i <= todayIndex; i++) {
            // If today is Tuesday (index 2), Sunday (index 0) gets data from 2 days ago (index 4 in raw array)
            currentWeekTotals[i] = rawDailyTotals[6 - (todayIndex - i)];
        }

        setupBarChart(currentWeekTotals);

        List<PieEntry> entries = dbHelper.getCategoryBreakdown("week");
        setupPieChart(entries);

        // Sum up ONLY the current week (Sunday to Today)
        double currentWeekTotal = 0;
        for (float val : currentWeekTotals) currentWeekTotal += val;

        float[] previousWeekTotals = dbHelper.getDailyTotals(14);
        double lastWeekTotal = 0;
        for (int i = 0; i < 7; i++) lastWeekTotal += previousWeekTotals[i];

        if (lastWeekTotal > 0) {
            double diff = ((currentWeekTotal - lastWeekTotal) / lastWeekTotal) * 100;
            String direction = diff >= 0 ? "↑" : "↓";
            tvWeekComparison.setText(String.format(Locale.getDefault(), "%s %.0f%% vs last week", direction, Math.abs(diff)));
            tvWeekComparison.setTextColor(diff > 0 ? Color.parseColor("#EF4444") : Color.parseColor("#2D6A4F"));
        } else {
            tvWeekComparison.setText("0% vs now");
            tvWeekComparison.setTextColor(Color.parseColor("#2D6A4F"));
        }
    }

    private void setupPieChart(List<PieEntry> entries) {
        double totalWeek = 0;
        for (PieEntry entry : entries) totalWeek += entry.getValue();
        tvTotalWeekEmissions.setText(String.format(Locale.getDefault(), "%.1f kg", totalWeek));

        weekPieChart.setDrawHoleEnabled(true);
        weekPieChart.setHoleColor(Color.WHITE);
        weekPieChart.setHoleRadius(82f);
        weekPieChart.setTransparentCircleRadius(0f);

        String centerText = String.format(Locale.getDefault(), "Emissions\n%.2f kg", totalWeek);
        SpannableString s = new SpannableString(centerText);
        s.setSpan(new RelativeSizeSpan(0.8f), 0, 9, 0);
        s.setSpan(new ForegroundColorSpan(Color.parseColor("#6B7280")), 0, 9, 0);
        s.setSpan(new StyleSpan(Typeface.BOLD), 10, centerText.length(), 0);
        s.setSpan(new RelativeSizeSpan(1.4f), 10, centerText.length(), 0);
        s.setSpan(new ForegroundColorSpan(Color.parseColor("#1F2937")), 10, centerText.length(), 0);

        weekPieChart.setCenterText(s);

        weekPieChart.getDescription().setEnabled(false);
        weekPieChart.getLegend().setEnabled(false);
        weekPieChart.setRotationEnabled(false);
        weekPieChart.setDrawEntryLabels(false);

        if (entries.isEmpty()) {
            ArrayList<PieEntry> emptyEntries = new ArrayList<>();
            emptyEntries.add(new PieEntry(1f, ""));
            PieDataSet dataSet = new PieDataSet(emptyEntries, "");
            dataSet.setColors(Color.parseColor("#F3F4F6"));
            dataSet.setDrawValues(false);
            weekPieChart.setData(new PieData(dataSet));
        } else {
            PieDataSet dataSet = new PieDataSet(entries, "");
            List<Integer> colors = new ArrayList<>();
            for (PieEntry entry : entries) {
                String label = entry.getLabel();
                if ("Transport".equals(label)) colors.add(Color.parseColor("#264F36"));
                else if ("Energy".equals(label)) colors.add(Color.parseColor("#D4734B"));
                else if ("Food".equals(label)) colors.add(Color.parseColor("#A06B9A"));
                else if ("Shopping".equals(label)) colors.add(Color.parseColor("#6BAABC"));
                else if ("Waste".equals(label)) colors.add(Color.parseColor("#D4CF4B"));
                else colors.add(Color.GRAY);
            }
            dataSet.setColors(colors);
            dataSet.setDrawValues(false);
            weekPieChart.setData(new PieData(dataSet));
        }

        weekPieChart.notifyDataSetChanged();
        weekPieChart.invalidate();

        if (getView() != null) {
            updateCategoryList(entries, totalWeek);
        }
    }

    private void updateCategoryList(List<PieEntry> entries, double total) {
        setupCategoryItem(getView().findViewById(R.id.itemTransport), "Transport", "#264F36", entries, total);
        setupCategoryItem(getView().findViewById(R.id.itemEnergy), "Energy", "#D4734B", entries, total);
        setupCategoryItem(getView().findViewById(R.id.itemFood), "Food", "#A06B9A", entries, total);
        setupCategoryItem(getView().findViewById(R.id.itemShopping), "Shopping", "#6BAABC", entries, total);
        setupCategoryItem(getView().findViewById(R.id.itemWaste), "Waste", "#D4CF4B", entries, total);
    }

    private void setupCategoryItem(View view, String name, String color, List<PieEntry> entries, double total) {
        if (view == null) return;
        View dot = view.findViewById(R.id.dotCategory);
        TextView tvName = view.findViewById(R.id.tvCategoryName);
        TextView tvKg = view.findViewById(R.id.tvCategoryKg);
        TextView tvPercent = view.findViewById(R.id.tvCategoryPercent);

        if (dot != null) dot.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(color)));
        if (tvName != null) tvName.setText(name);

        float val = 0;
        for (PieEntry e : entries) {
            if (name.equals(e.getLabel())) {
                val = e.getValue();
                break;
            }
        }

        if (tvKg != null) tvKg.setText(String.format(Locale.getDefault(), "%.1f kg", val));
        int percent = total == 0 ? 0 : (int) ((val / total) * 100);
        if (tvPercent != null) tvPercent.setText(String.format(Locale.getDefault(), "%d%%", percent));
    }

    private void setupBarChart(float[] dailyValues) {
        barChart.getDescription().setEnabled(false);
        barChart.getLegend().setEnabled(false);
        barChart.setScaleEnabled(false);
        barChart.setDrawBorders(false);

        // Fixed X-Axis from Sunday to Saturday
        String[] days = new String[]{"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};

        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(days));
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);
        xAxis.setTextColor(Color.parseColor("#6B7280"));
        xAxis.setTextSize(12f);

        YAxis leftAxis = barChart.getAxisLeft();
        leftAxis.setAxisMinimum(0f);
        leftAxis.setDrawLabels(false);
        leftAxis.setDrawGridLines(false);
        leftAxis.setDrawAxisLine(false);

        barChart.getAxisRight().setEnabled(false);

        updateBarChartData(dailyValues);
    }

    public void updateBarChartData(float[] dailyValues) {
        ArrayList<BarEntry> entries = new ArrayList<>();
        List<Integer> colors = new ArrayList<>();

        for (int i = 0; i < dailyValues.length && i < 7; i++) {
            float value = dailyValues[i];
            entries.add(new BarEntry(i, value));

            if (value > HIGH_EMISSION_THRESHOLD) {
                colors.add(Color.parseColor("#EF4444")); // Red
            } else {
                colors.add(Color.parseColor("#2D6A4F")); // Green
            }
        }

        BarDataSet dataSet = new BarDataSet(entries, "Weekly Emissions");
        dataSet.setColors(colors);
        dataSet.setDrawValues(false);

        BarData barData = new BarData(dataSet);
        barData.setBarWidth(0.4f);

        barChart.setData(barData);
        barChart.notifyDataSetChanged();
        barChart.invalidate();
    }
}