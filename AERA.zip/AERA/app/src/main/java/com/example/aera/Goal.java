package com.example.aera;

public class Goal {
    private int id;
    private String title;
    private String description;
    private int targetPercentage;
    private int progressPercentage;
    private String period;
    private String category;
    private boolean isCompleted;
    private long createdAt; // NEW: Timestamp field

    public Goal(int id, String title, String description, int targetPercentage, int progressPercentage, String period, String category, boolean isCompleted, long createdAt) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.targetPercentage = targetPercentage;
        this.progressPercentage = progressPercentage;
        this.period = period;
        this.category = category;
        this.isCompleted = isCompleted;
        this.createdAt = createdAt; // NEW: Initialize timestamp
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public int getTargetPercentage() { return targetPercentage; }
    public int getProgressPercentage() { return progressPercentage; }
    public String getPeriod() { return period; }
    public String getCategory() { return category; }
    public boolean isCompleted() { return isCompleted; }

    // NEW: Getter for the timestamp
    public long getCreatedAt() { return createdAt; }
}