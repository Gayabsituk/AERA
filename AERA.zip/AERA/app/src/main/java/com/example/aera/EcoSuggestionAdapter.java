package com.example.aera;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class EcoSuggestionAdapter extends RecyclerView.Adapter<EcoSuggestionAdapter.ViewHolder> {

    public static class EcoSuggestion {
        private String category;
        private String description;
        private float percentage; // Impact percentage

        public EcoSuggestion(String category, String description, float percentage) {
            this.category = category;
            this.description = description;
            this.percentage = percentage;
        }

        public String getCategory() { return category; }
        public String getDescription() { return description; }
        public float getPercentage() { return percentage; }
    }

    private List<EcoSuggestion> suggestionList = new ArrayList<>();

    public void updateList(List<EcoSuggestion> newList) {
        this.suggestionList = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_eco_suggestion, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        EcoSuggestion suggestion = suggestionList.get(position);

        // Display ONLY the category name
        holder.tipTag.setText(suggestion.getCategory());
        holder.tipDescription.setText(suggestion.getDescription());

        // Make the leaf icon explicitly green across items
        if (holder.leafIcon != null) {
            holder.leafIcon.setColorFilter(Color.parseColor("#166534"));
        }

        // Color coding & icon selection based on impact percentage:
        // Good (< 20%) -> Green (Safe icon)
        // Medium (20% - 40%) -> Yellow (Medium Safe icon)
        // Bad (> 40%) -> Red (Warning icon)
        float pct = suggestion.getPercentage();
        if (pct > 40f) {
            // Bad (Red)
            holder.tipTagLayout.setBackgroundColor(Color.parseColor("#FDF2F2"));
            holder.tipTag.setTextColor(Color.parseColor("#7F1D1D"));
            holder.tipTagIcon.setColorFilter(Color.parseColor("#7F1D1D"));
            holder.tipTagIcon.setImageResource(R.drawable.ic_warning);
        } else if (pct > 20f) {
            // Medium (Yellow/Orange)
            holder.tipTagLayout.setBackgroundColor(Color.parseColor("#FEFCE8"));
            holder.tipTag.setTextColor(Color.parseColor("#854D0E"));
            holder.tipTagIcon.setColorFilter(Color.parseColor("#854D0E"));
            holder.tipTagIcon.setImageResource(R.drawable.ic_medium_safe_yellow);
        } else {
            // Good (Green)
            holder.tipTagLayout.setBackgroundColor(Color.parseColor("#F0FDF4"));
            holder.tipTag.setTextColor(Color.parseColor("#166534"));
            holder.tipTagIcon.setColorFilter(Color.parseColor("#166534"));
            holder.tipTagIcon.setImageResource(R.drawable.ic_safe_green);
        }
    }

    @Override
    public int getItemCount() {
        return suggestionList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tipTag, tipDescription;
        ImageView tipTagIcon, leafIcon;
        LinearLayout tipTagLayout;

        ViewHolder(View itemView) {
            super(itemView);
            tipTag = itemView.findViewById(R.id.tipTag);
            tipDescription = itemView.findViewById(R.id.tipDescription);
            tipTagIcon = itemView.findViewById(R.id.tipTagIcon);
            tipTagLayout = itemView.findViewById(R.id.tipTagLayout);
            leafIcon = itemView.findViewById(R.id.ic_leaf);
        }
    }
}