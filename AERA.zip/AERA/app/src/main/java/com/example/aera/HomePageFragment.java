package com.example.aera;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.github.mikephil.charting.data.PieEntry;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class HomePageFragment extends Fragment {

    private CircularProgressIndicator co2ProgressRing;
    private TextView co2AmountText;
    private TextView nameText;
    private TextView warningText;
    private ImageView warningIcon;

    private RecyclerView rvEcoSuggestions;
    private View ecoSuggestionsScrollView;
    private EcoSuggestionAdapter ecoAdapter;
    private TextView ecoSuggestionsTitle;

    private DatabaseHelper dbHelper;

    private static final String PREFS_NAME = "AeraPrefs";
    private static final String KEY_USER_NAME = "user_name";
    private static final float DAILY_CO2_LIMIT = 25.0f;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home_page, container, false);

        try {
            if (getActivity() instanceof Aera) {
                ((Aera) getActivity()).setBottomNavigationVisibility(true);
                ((Aera) getActivity()).updateBottomNavSelection(R.id.nav_home);
            }
        } catch (Exception e) {
            Log.e("HomePage", "Navigation update error: " + e.getMessage());
        }

        try {
            dbHelper = new DatabaseHelper(requireContext());
        } catch (Exception e) {
            Log.e("HomePage", "Database Error: " + e.getMessage());
        }

        co2ProgressRing = view.findViewById(R.id.co2ProgressRing);
        co2AmountText = view.findViewById(R.id.co2AmountText);
        nameText = view.findViewById(R.id.nameText);
        warningText = view.findViewById(R.id.warningText);
        warningIcon = view.findViewById(R.id.warningIcon);

        ecoSuggestionsTitle = view.findViewById(R.id.ecoSuggestionsTitle);
        ecoSuggestionsScrollView = view.findViewById(R.id.ecoSuggestionsScrollView);
        rvEcoSuggestions = view.findViewById(R.id.rvEcoSuggestions);

        if (rvEcoSuggestions != null) {
            rvEcoSuggestions.setLayoutManager(new LinearLayoutManager(requireContext()));
            ecoAdapter = new EcoSuggestionAdapter();
            rvEcoSuggestions.setAdapter(ecoAdapter);
        }

        loadLocalData();
        checkAndResetDailyStats();

        if (nameText != null) {
            String userName = nameText.getText().toString();
            if (!userName.isEmpty() && savedInstanceState == null) {
                Toast.makeText(requireContext(), "Welcome, " + userName + "!", Toast.LENGTH_SHORT).show();
            }
        }

        view.findViewById(R.id.btnQuickLogTransport).setOnClickListener(v -> navigateToLogActivity("Transport"));
        view.findViewById(R.id.btnQuickLogEnergy).setOnClickListener(v -> navigateToLogActivity("Energy"));
        view.findViewById(R.id.btnQuickLogFood).setOnClickListener(v -> navigateToLogActivity("Food"));
        view.findViewById(R.id.btnQuickLogShopping).setOnClickListener(v -> navigateToLogActivity("Shopping"));
        view.findViewById(R.id.btnQuickLogWaste).setOnClickListener(v -> navigateToLogActivity("Waste"));

        return view;
    }

    private void checkAndResetDailyStats() {
        try {
            SharedPreferences prefs = requireActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String lastLogDate = prefs.getString("LAST_LOG_DATE", "");

            // Format current date explicitly using Philippine Standard Time (Asia/Manila)
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            sdf.setTimeZone(TimeZone.getTimeZone("Asia/Manila"));
            String currentDate = sdf.format(new Date());

            if (!currentDate.equals(lastLogDate)) {
                // A new day in the Philippines has started (12:00 AM turnover)
                prefs.edit().putString("LAST_LOG_DATE", currentDate).apply();
            }

            updatePieChartUI();
            checkAndDisplayEcoTips();

        } catch (Exception e) {
            Log.e("HomePage", "Reset Stats Error: " + e.getMessage());
        }
    }

    private void updatePieChartUI() {
        try {
            if (dbHelper != null && co2AmountText != null && co2ProgressRing != null) {
                float todayCO2 = (float) dbHelper.getTodayTotalCO2();
                int percentageUsed = (int) ((todayCO2 / DAILY_CO2_LIMIT) * 100);
                int percentageRemaining = 100 - percentageUsed;

                if (percentageRemaining < 0) percentageRemaining = 0; // Prevent negatives

                co2AmountText.setText(String.format(Locale.getDefault(), "%.1f", todayCO2));
                co2ProgressRing.setProgress(Math.min(percentageUsed, 100));

                if (percentageRemaining >= 80) {
                    warningText.setText(percentageRemaining + "% of daily limit remaining");
                    warningText.setTextColor(Color.parseColor("#2D6A4F"));
                    warningIcon.setImageResource(R.drawable.ic_safe_green);
                    warningIcon.setColorFilter(Color.parseColor("#2D6A4F"));
                    co2ProgressRing.setIndicatorColor(Color.parseColor("#2D6A4F"));
                } else if (percentageRemaining > 30) {
                    warningText.setText(percentageRemaining + "% of daily limit remaining");
                    warningText.setTextColor(Color.parseColor("#D97706"));
                    warningIcon.setImageResource(R.drawable.ic_medium_safe_yellow);
                    warningIcon.setColorFilter(Color.parseColor("#D97706"));
                    co2ProgressRing.setIndicatorColor(Color.parseColor("#D97706"));
                } else {
                    warningText.setText(percentageRemaining + "% of daily limit remaining");
                    warningText.setTextColor(Color.parseColor("#B71C1C"));
                    warningIcon.setImageResource(R.drawable.ic_warning);
                    warningIcon.setColorFilter(Color.parseColor("#B71C1C"));
                    co2ProgressRing.setIndicatorColor(Color.parseColor("#B71C1C"));
                }
            }
        } catch (Exception e) {
            Log.e("HomePage", "Error updating pie chart: " + e.getMessage());
        }
    }

    private void loadLocalData() {
        try {
            SharedPreferences preferences = requireActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            if (preferences.contains(KEY_USER_NAME) && nameText != null) {
                nameText.setText(preferences.getString(KEY_USER_NAME, ""));
            }
        } catch (Exception e) {
            Log.e("HomePage", "Error loading SharedPreferences: " + e.getMessage());
        }
    }

    private void navigateToLogActivity(String category) {
        LogActivityFragment logFragment = new LogActivityFragment();
        Bundle args = new Bundle();
        args.putString("SELECTED_CATEGORY", category);
        logFragment.setArguments(args);

        requireActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, logFragment)
                .addToBackStack(null)
                .commit();
    }

    private void checkAndDisplayEcoTips() {
        if (rvEcoSuggestions == null) return;

        List<PieEntry> entries = dbHelper.getCategoryBreakdown("day");
        double totalToday = 0;
        for (PieEntry entry : entries) {
            totalToday += entry.getValue();
        }

        List<EcoSuggestionAdapter.EcoSuggestion> suggestions = new ArrayList<>();

        if (totalToday > 0 && !entries.isEmpty()) {
            for (PieEntry entry : entries) {
                if (entry.getValue() > 0) {
                    String categoryName = entry.getLabel();
                    float categoryPercentage = totalToday > 0 ? (float) ((entry.getValue() / totalToday) * 100) : 0f;
                    String tipText = getTipTextForCategory(categoryName, categoryPercentage);

                    suggestions.add(new EcoSuggestionAdapter.EcoSuggestion(categoryName, tipText, categoryPercentage));
                }
            }
        } else {
            suggestions.add(new EcoSuggestionAdapter.EcoSuggestion(
                    "Getting Started",
                    "Welcome to Aera! Log your first activity today to begin tracking your carbon footprint.",
                    10.0f
            ));
            suggestions.add(new EcoSuggestionAdapter.EcoSuggestion(
                    "Daily Habit",
                    "Aim to walk or use public transportation for short trips to keep your transport emissions low.",
                    40.0f
            ));
            suggestions.add(new EcoSuggestionAdapter.EcoSuggestion(
                    "Footprint Alert",
                    "Unmonitored energy and waste can quickly pile up. Stay mindful of your resource usage!",
                    80.0f
            ));
        }

        if (ecoSuggestionsTitle != null) {
            ecoSuggestionsTitle.setVisibility(View.VISIBLE);
            ecoSuggestionsTitle.setText("Eco-Friendly Suggestions");
        }
        if (ecoSuggestionsScrollView != null) {
            ecoSuggestionsScrollView.setVisibility(View.VISIBLE);
        }

        ecoAdapter.updateList(suggestions);
    }

    private String getTipTextForCategory(String categoryName, float categoryPercentage) {
        switch (categoryName) {
            case "Transport":
                if (categoryPercentage > 40f) {
                    return "Your transport footprint is very high today! Try switching entirely to public transit, carpooling, or walking for your trips.";
                } else if (categoryPercentage > 20f) {
                    return "Consider carpooling, public transit, or walking for shorter trips to cut down transport emissions.";
                } else {
                    return "Great job keeping your transport emissions low today! Keep choosing sustainable transit options.";
                }

            case "Energy":
                if (categoryPercentage > 40f) {
                    return "Energy usage is spiking today. Unplug idle electronics and reduce heavy appliance usage immediately.";
                } else if (categoryPercentage > 20f) {
                    return "Turn off unused appliances and optimize heating/cooling to reduce energy waste.";
                } else {
                    return "Your energy consumption is well-managed today. Keep up the efficient habits!";
                }

            case "Food":
                if (categoryPercentage > 40f) {
                    return "Food-related emissions are taking up a major portion of your footprint. Opt for plant-based or hyper-local meals next.";
                } else if (categoryPercentage > 20f) {
                    return "Choose lower-impact local foods and avoid wasting food whenever possible.";
                } else {
                    return "Your food choices have a low environmental impact today. Excellent work!";
                }

            case "Shopping":
                if (categoryPercentage > 40f) {
                    return "Shopping and retail make up most of your footprint today. Try to avoid non-essential purchases.";
                } else if (categoryPercentage > 20f) {
                    return "Prioritize durable goods and second-hand items to minimize purchase footprints.";
                } else {
                    return "Minimal shopping footprint today—you're doing great at avoiding unnecessary consumer waste.";
                }

            case "Waste":
                if (categoryPercentage > 40f) {
                    return "Your waste levels are high. Focus heavily on sorting recyclables and minimizing single-use items.";
                } else if (categoryPercentage > 20f) {
                    return "Focus on recycling, composting organic waste, and avoiding single-use plastics.";
                } else {
                    return "Low waste footprint today! Your recycling and reduction efforts are paying off.";
                }

            default:
                if (categoryPercentage > 30f) {
                    return "This category is driving up your daily footprint. Try to look for alternative habits here.";
                } else {
                    return "Small daily changes can significantly reduce your carbon footprint.";
                }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        checkAndResetDailyStats();
        checkAndDisplayEcoTips();
    }
}