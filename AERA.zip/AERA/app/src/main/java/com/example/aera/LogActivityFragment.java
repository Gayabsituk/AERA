package com.example.aera;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.chip.ChipGroup;

import java.util.HashMap;
import java.util.Map;

public class LogActivityFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private String currentCategory = "Transport";

    // UI Elements
    private LinearLayout layoutTransport, layoutEnergy, layoutGeneral;
    private ChipGroup chipGroup;
    private Spinner spinnerTransport, spinnerSubtype;
    private ImageView ivTransportArrow, ivSubtypeArrow;
    private ImageView ivSubtypeLeftIcon; // Left icon in the general dropdown
    private EditText etDistance, etTrips, etPassengers, etKwh, etAmount;
    private TextView tvEstimatedFootprint, tvSubtypeLabel, tvAmountLabel, tvUnit;

    // Data Factors
    private final Map<String, Double> transportFactors = new HashMap<>();
    private final Map<String, Double> foodFactors = new HashMap<>();
    private final Map<String, Double> shoppingFactors = new HashMap<>();
    private final Map<String, Double> wasteFactors = new HashMap<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.log_activity, container, false);

        if (getActivity() instanceof Aera) {
            ((Aera) requireActivity()).setBottomNavigationVisibility(false);
        }

        dbHelper = new DatabaseHelper(requireContext());

        initData();
        initViews(view);
        setupCategorySwitching();
        setupRealTimeCalculation();

        view.findViewById(R.id.btn_back).setOnClickListener(v -> requireActivity().getSupportFragmentManager().popBackStack());
        view.findViewById(R.id.btn_save).setOnClickListener(v -> saveEntry());

        BottomNavigationView bottomNavigation = view.findViewById(R.id.bottomNavigation);
        if (bottomNavigation != null) {
            bottomNavigation.setSelectedItemId(R.id.nav_activity);

            bottomNavigation.setOnItemSelectedListener(item -> {
                Fragment selectedFragment = null;
                int itemId = item.getItemId();

                if (itemId == R.id.nav_home) {
                    selectedFragment = new HomePageFragment();
                } else if (itemId == R.id.nav_activity) {
                    return true;
                } else if (itemId == R.id.nav_analytics) {
                    selectedFragment = new AnalyticsFragment();
                } else if (itemId == R.id.nav_goals) {
                    selectedFragment = new GoalsFragment();
                } else if (itemId == R.id.nav_settings) {
                    selectedFragment = new SettingsFragment();
                }

                if (selectedFragment != null) {
                    requireActivity().getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, selectedFragment)
                            .commit();
                    return true;
                }
                return false;
            });
        }

        if (getArguments() != null) {
            String passedCategory = getArguments().getString("SELECTED_CATEGORY", "Transport");
            selectCategoryChip(passedCategory);
        }

        return view;
    }

    private void selectCategoryChip(String category) {
        switch (category) {
            case "Transport": chipGroup.check(R.id.chip_transport); break;
            case "Energy": chipGroup.check(R.id.chip_energy); break;
            case "Food": chipGroup.check(R.id.chip_food); break;
            case "Shopping": chipGroup.check(R.id.chip_shopping); break;
            case "Waste": chipGroup.check(R.id.chip_waste); break;
        }
    }

    private void initData() {
        transportFactors.put("Motorcycle", 0.266);
        transportFactors.put("Tricycle", 0.266);
        transportFactors.put("Car", 0.319);
        transportFactors.put("Taxi", 0.292);
        transportFactors.put("Jeepney", 0.415);
        transportFactors.put("Bus", 1.097);
        transportFactors.put("UV/Van", 0.415);

        foodFactors.put("High-Impact Meat", 27.0);
        foodFactors.put("Medium-Impact Meat", 8.0);
        foodFactors.put("Low-Impact Meat", 6.0);
        foodFactors.put("Seafood", 5.0);
        foodFactors.put("Dairy & Eggs", 4.0);
        foodFactors.put("Grains & Staples", 2.5);
        foodFactors.put("Fruits & Vegetables", 0.9);
        foodFactors.put("Legumes & Plant-Based", 1.0);
        foodFactors.put("Processed & Packaged", 2.5);
        foodFactors.put("Sweets & Desserts", 5.0);
        foodFactors.put("Beverages", 1.5);

        shoppingFactors.put("Clothing & Footwear", 15.0);
        shoppingFactors.put("Electronics", 100.0);
        shoppingFactors.put("Furniture", 50.0);
        shoppingFactors.put("Household Products", 5.0);
        shoppingFactors.put("Personal Care", 2.0);
        shoppingFactors.put("Paper Products", 1.5);
        shoppingFactors.put("Plastic Products", 3.0);
        shoppingFactors.put("Other Retail Goods", 5.0);

        wasteFactors.put("Food Waste", 0.5);
        wasteFactors.put("Paper & Cardboard", 1.5);
        wasteFactors.put("Plastic", 3.0);
        wasteFactors.put("Glass", 0.9);
        wasteFactors.put("Metal", 2.0);
        wasteFactors.put("Textiles", 5.0);
        wasteFactors.put("Electronic Waste", 20.0);
        wasteFactors.put("Mixed/General Waste", 2.0);
    }

    private void initViews(View view) {
        layoutTransport = view.findViewById(R.id.layout_transport);
        layoutEnergy = view.findViewById(R.id.layout_energy);
        layoutGeneral = view.findViewById(R.id.layout_general);
        chipGroup = view.findViewById(R.id.chip_group_category);

        spinnerTransport = view.findViewById(R.id.spinner_transport_type);
        spinnerSubtype = view.findViewById(R.id.spinner_subtype);

        ivTransportArrow = view.findViewById(R.id.iv_transport_arrow);
        ivSubtypeArrow = view.findViewById(R.id.iv_subtype_arrow);
        ivSubtypeLeftIcon = view.findViewById(R.id.iv_subtype_left_icon);

        etDistance = view.findViewById(R.id.et_distance);
        etTrips = view.findViewById(R.id.et_trips);
        etPassengers = view.findViewById(R.id.et_passengers);
        etKwh = view.findViewById(R.id.et_kwh);
        etAmount = view.findViewById(R.id.et_amount);

        tvEstimatedFootprint = view.findViewById(R.id.tv_estimated_footprint);
        tvSubtypeLabel = view.findViewById(R.id.tv_subtype_label);
        tvAmountLabel = view.findViewById(R.id.tv_amount_label);
        tvUnit = view.findViewById(R.id.tv_unit);

        setupSpinnerArrowBehavior(spinnerTransport, ivTransportArrow);
        setupSpinnerArrowBehavior(spinnerSubtype, ivSubtypeArrow);

        setupSpinner(spinnerTransport, transportFactors.keySet().toArray(new String[0]));
    }

    private void setupSpinnerArrowBehavior(Spinner spinner, ImageView arrowIcon) {
        spinner.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                arrowIcon.setImageResource(R.drawable.ic_chevron_up);
            }
            return false;
        });
        spinner.getViewTreeObserver().addOnWindowFocusChangeListener(hasFocus -> {
            if (hasFocus) {
                arrowIcon.setImageResource(R.drawable.ic_chevron_down);
            }
        });
    }
    private void setupCategorySwitching() {
        chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int checkedId = checkedIds.get(0);

            layoutTransport.setVisibility(View.GONE);
            layoutEnergy.setVisibility(View.GONE);
            layoutGeneral.setVisibility(View.GONE);
            tvUnit.setVisibility(View.VISIBLE);

            if (checkedId == R.id.chip_transport) {
                currentCategory = "Transport";
                layoutTransport.setVisibility(View.VISIBLE);
            } else if (checkedId == R.id.chip_energy) {
                currentCategory = "Energy";
                layoutEnergy.setVisibility(View.VISIBLE);
            } else if (checkedId == R.id.chip_food) {
                currentCategory = "Food";
                layoutGeneral.setVisibility(View.VISIBLE);

                // Set Icon and its Color dynamically
                ivSubtypeLeftIcon.setImageResource(R.drawable.ic_food);
                ivSubtypeLeftIcon.setColorFilter(Color.parseColor("#3730A3")); // Indigo Food

                updateGeneralUI("Food Type", "Serving/Amount", "kg", foodFactors.keySet().toArray(new String[0]));
            } else if (checkedId == R.id.chip_shopping) {
                currentCategory = "Shopping";
                layoutGeneral.setVisibility(View.VISIBLE);

                // Set Icon and its Color dynamically
                ivSubtypeLeftIcon.setImageResource(R.drawable.ic_shopping);
                ivSubtypeLeftIcon.setColorFilter(Color.parseColor("#7C3AED")); // Purple Shopping

                updateGeneralUI("Category", "Number of Items", "", shoppingFactors.keySet().toArray(new String[0]));
                tvUnit.setVisibility(View.GONE); // No unit string needed for items
            } else if (checkedId == R.id.chip_waste) {
                currentCategory = "Waste";
                layoutGeneral.setVisibility(View.VISIBLE);

                // Set Icon and its Color dynamically
                ivSubtypeLeftIcon.setImageResource(R.drawable.ic_waste);
                ivSubtypeLeftIcon.setColorFilter(Color.parseColor("#606C38")); // Olive Waste

                updateGeneralUI("Type of Waste", "Weight", "kg", wasteFactors.keySet().toArray(new String[0]));
            }
            calculateFootprint();
        });
    }

    private void updateGeneralUI(String label, String amountLabel, String unit, String[] types) {
        tvSubtypeLabel.setText(label);
        tvAmountLabel.setText(amountLabel);
        tvUnit.setText(unit);
        setupSpinner(spinnerSubtype, types);
    }

    private void setupSpinner(Spinner spinner, String[] items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                calculateFootprint();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupRealTimeCalculation() {
        TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { calculateFootprint(); }
            @Override public void afterTextChanged(Editable s) {}
        };
        etDistance.addTextChangedListener(tw);
        etTrips.addTextChangedListener(tw);
        etPassengers.addTextChangedListener(tw);
        etKwh.addTextChangedListener(tw);
        etAmount.addTextChangedListener(tw);
    }

    private void calculateFootprint() {
        double result = 0;
        switch (currentCategory) {
            case "Transport":
                if (spinnerTransport.getSelectedItem() != null) {
                    String tType = spinnerTransport.getSelectedItem().toString();
                    double dist = getDouble(etDistance);
                    double trips = getDouble(etTrips);
                    double pass = getDouble(etPassengers);
                    if (pass == 0) pass = 1;
                    if (transportFactors.containsKey(tType)) {
                        result = (dist * trips * transportFactors.get(tType)) / pass;
                    }
                }
                break;
            case "Energy":
                result = getDouble(etKwh) * 0.70;
                break;
            case "Food":
                if (spinnerSubtype.getSelectedItem() != null) {
                    result = getDouble(etAmount) * foodFactors.getOrDefault(spinnerSubtype.getSelectedItem().toString(), 0.0);
                }
                break;
            case "Shopping":
                if (spinnerSubtype.getSelectedItem() != null) {
                    result = getDouble(etAmount) * shoppingFactors.getOrDefault(spinnerSubtype.getSelectedItem().toString(), 0.0);
                }
                break;
            case "Waste":
                if (spinnerSubtype.getSelectedItem() != null) {
                    result = getDouble(etAmount) * wasteFactors.getOrDefault(spinnerSubtype.getSelectedItem().toString(), 0.0);
                }
                break;
        }
        tvEstimatedFootprint.setText(String.format("%.2f kg CO₂e", result));
    }

    private void saveEntry() {
        if (!validateInputs()) return;

        double co2e = 0;
        try {
            co2e = Double.parseDouble(tvEstimatedFootprint.getText().toString().split(" ")[0]);
        } catch (Exception e) {
            co2e = 0.0;
        }

        String subtype = "";
        double val = 0;
        switch (currentCategory) {
            case "Transport":
                subtype = spinnerTransport.getSelectedItem() != null ? spinnerTransport.getSelectedItem().toString() : "Unknown";
                val = getDouble(etDistance);
                break;
            case "Energy":
                subtype = "Electricity";
                val = getDouble(etKwh);
                break;
            default:
                subtype = spinnerSubtype.getSelectedItem() != null ? spinnerSubtype.getSelectedItem().toString() : "Unknown";
                val = getDouble(etAmount);
                break;
        }

        dbHelper.addActivity(currentCategory, subtype, val, co2e);
        Toast.makeText(requireContext(), "Activity Logged!", Toast.LENGTH_SHORT).show();
        requireActivity().getSupportFragmentManager().popBackStack();
    }

    private boolean validateInputs() {
        boolean valid = true;
        switch (currentCategory) {
            case "Transport":
                if (etDistance.getText().toString().isEmpty()) { etDistance.setError("Required"); valid = false; }
                if (etTrips.getText().toString().isEmpty()) { etTrips.setError("Required"); valid = false; }
                if (etPassengers.getText().toString().isEmpty()) { etPassengers.setError("Required"); valid = false; }
                break;
            case "Energy":
                if (etKwh.getText().toString().isEmpty()) { etKwh.setError("Required"); valid = false; }
                break;
            default:
                if (etAmount.getText().toString().isEmpty()) { etAmount.setError("Required"); valid = false; }
                break;
        }
        if (!valid) Toast.makeText(requireContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
        return valid;
    }

    private double getDouble(EditText et) {
        try { return Double.parseDouble(et.getText().toString()); }
        catch (Exception e) { return 0; }
    }
}