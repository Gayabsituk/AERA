package com.example.aera;

import androidx.appcompat.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;
import java.util.LinkedHashMap;
import java.util.Map;

public class LogActivityFragment extends Fragment {

    private DatabaseHelper dbHelper;
    private String currentCategory = "Transport";
    private int editId = -1;
    private boolean isInitializingEdit = false;

    // To track original values for edit mode comparison
    private String originalSubtype = "";
    private double originalValue = 0;

    // Separated UI Elements
    private LinearLayout layoutTransport, layoutEnergy, layoutFood, layoutShopping, layoutWaste;
    private ChipGroup chipGroup;
    private Spinner spinnerTransport, spinnerFood, spinnerShopping, spinnerWaste;
    private EditText etDistance, etTrips, etPassengers, etKwh, etFoodAmount, etShoppingAmount, etWasteAmount;
    private TextView tvEstimatedFootprint, tvTitle;
    private MaterialButton btnSave, btnDelete;

    // Data Factors
    private final Map<String, Double> transportFactors = new LinkedHashMap<>();
    private final Map<String, Double> foodFactors = new LinkedHashMap<>();
    private final Map<String, Double> shoppingFactors = new LinkedHashMap<>();
    private final Map<String, Double> wasteFactors = new LinkedHashMap<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.log_activity, container, false);

        if (getActivity() instanceof Aera) {
            ((Aera) requireActivity()).setBottomNavigationVisibility(false);
        }

        dbHelper = new DatabaseHelper(requireContext());

        initData();
        initViews(view);
        setupCategorySwitching();
        setupRealTimeCalculation();
        setupBottomNavigation(view);

        // Safeguard back button with conditional check
        View btnBack = view.findViewById(R.id.btn_back);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                if (hasUserMadeChanges()) {
                    showNavigationWarningDialog(-1);
                } else {
                    navigateAway(-1);
                }
            });
        }

        if (btnSave != null) {
            btnSave.setText("Save Activity");
            btnSave.setOnClickListener(v -> {
                if (editId != -1) {
                    confirmUpdate();
                } else {
                    saveEntry();
                }
            });
        }

        if (getArguments() != null) {
            isInitializingEdit = true;
            editId = getArguments().getInt("EDIT_ID", -1);
            String passedCategory = getArguments().getString("SELECTED_CATEGORY", "Transport");

            if (chipGroup != null) {
                selectCategoryChip(passedCategory);
            }

            if (editId != -1) {
                if (btnSave != null) btnSave.setText("Save Activity");
                if (tvTitle != null) tvTitle.setText("Edit Activity");

                if (btnDelete != null) {
                    btnDelete.setVisibility(View.VISIBLE);
                    btnDelete.setText("Delete Activity");
                    btnDelete.setOnClickListener(v -> confirmDelete());
                }

                double val = getArguments().getDouble("EDIT_VALUE", 0);
                String subtype = getArguments().getString("EDIT_SUBTYPE", "");

                // Store original values to check if user changes them later
                originalValue = val;
                originalSubtype = subtype;

                String formattedVal = val == (long) val ? String.format(java.util.Locale.getDefault(), "%d", (long) val) : String.valueOf(val);

                view.post(() -> {
                    if (passedCategory.equals("Transport")) {
                        if (etDistance != null) etDistance.setText(formattedVal);
                        if (etTrips != null) etTrips.setText("1");
                        if (etPassengers != null) etPassengers.setText("1");
                        setSpinnerSelection(spinnerTransport, subtype);
                    } else if (passedCategory.equals("Energy")) {
                        if (etKwh != null) etKwh.setText(formattedVal);
                    } else if (passedCategory.equals("Food")) {
                        if (etFoodAmount != null) etFoodAmount.setText(formattedVal);
                        setSpinnerSelection(spinnerFood, subtype);
                    } else if (passedCategory.equals("Shopping")) {
                        if (etShoppingAmount != null) etShoppingAmount.setText(formattedVal);
                        setSpinnerSelection(spinnerShopping, subtype);
                    } else if (passedCategory.equals("Waste")) {
                        if (etWasteAmount != null) etWasteAmount.setText(formattedVal);
                        setSpinnerSelection(spinnerWaste, subtype);
                    }
                    calculateFootprint();
                    isInitializingEdit = false;
                });
            } else {
                isInitializingEdit = false;
            }
        }

        return view;
    }

    // --- Conditional Check: Returns true if inputs are filled or modified ---
    private boolean hasUserMadeChanges() {
        if (editId == -1) {
            // New entry: Check if any field has text entered
            boolean transportFilled = (etDistance != null && !etDistance.getText().toString().trim().isEmpty()) ||
                    (etTrips != null && !etTrips.getText().toString().trim().equals("1") && !etTrips.getText().toString().trim().isEmpty()) ||
                    (etPassengers != null && !etPassengers.getText().toString().trim().equals("1") && !etPassengers.getText().toString().trim().isEmpty());

            boolean energyFilled = (etKwh != null && !etKwh.getText().toString().trim().isEmpty());
            boolean foodFilled = (etFoodAmount != null && !etFoodAmount.getText().toString().trim().isEmpty());
            boolean shoppingFilled = (etShoppingAmount != null && !etShoppingAmount.getText().toString().trim().isEmpty());
            boolean wasteFilled = (etWasteAmount != null && !etWasteAmount.getText().toString().trim().isEmpty());

            return transportFilled || energyFilled || foodFilled || shoppingFilled || wasteFilled;
        } else {
            // Edit mode: Check if values or selected subtype have changed from original
            double currentValue = 0;
            String currentSubtype = "";

            switch (currentCategory) {
                case "Transport":
                    currentValue = getDouble(etDistance);
                    currentSubtype = spinnerTransport != null && spinnerTransport.getSelectedItem() != null ? spinnerTransport.getSelectedItem().toString() : "";
                    break;
                case "Energy":
                    currentValue = getDouble(etKwh);
                    currentSubtype = "Electricity";
                    break;
                case "Food":
                    currentValue = getDouble(etFoodAmount);
                    currentSubtype = spinnerFood != null && spinnerFood.getSelectedItem() != null ? spinnerFood.getSelectedItem().toString() : "";
                    break;
                case "Shopping":
                    currentValue = getDouble(etShoppingAmount);
                    currentSubtype = spinnerShopping != null && spinnerShopping.getSelectedItem() != null ? spinnerShopping.getSelectedItem().toString() : "";
                    break;
                case "Waste":
                    currentValue = getDouble(etWasteAmount);
                    currentSubtype = spinnerWaste != null && spinnerWaste.getSelectedItem() != null ? spinnerWaste.getSelectedItem().toString() : "";
                    break;
            }

            return (currentValue != originalValue) || !currentSubtype.equalsIgnoreCase(originalSubtype);
        }
    }

    private void setupBottomNavigation(View view) {
        BottomNavigationView bottomNavigation = view.findViewById(R.id.bottomNavigation);
        if (bottomNavigation != null) {
            bottomNavigation.setSelectedItemId(R.id.nav_activity);
            bottomNavigation.setOnItemSelectedListener(item -> {
                int itemId = item.getItemId();
                if (itemId == R.id.nav_activity) return true;

                // Conditional check for Bottom Navigation switching
                if (hasUserMadeChanges()) {
                    showNavigationWarningDialog(itemId);
                } else {
                    navigateAway(itemId);
                }
                return false;
            });
        }
    }

    private void showCustomDialog(String title, String message, String posText, String negText, String posColorHex, Runnable onPositive, Runnable onNegative) {
        if (!isAdded() || getActivity() == null) return;
        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
            View view = getLayoutInflater().inflate(R.layout.dialog_layout, null);
            builder.setView(view);
            AlertDialog dialog = builder.create();

            if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

            TextView tvTitle = view.findViewById(R.id.tv_dialog_title);
            TextView tvMessage = view.findViewById(R.id.tv_dialog_message);
            TextView btnNegative = view.findViewById(R.id.btn_dialog_negative);
            TextView btnPositive = view.findViewById(R.id.btn_dialog_positive);

            if (tvTitle == null || btnPositive == null) {
                if (onPositive != null) onPositive.run();
                return;
            }

            tvTitle.setText(title);
            tvMessage.setText(message);

            if (btnNegative != null) {
                btnNegative.setText(negText);
                btnNegative.setOnClickListener(v -> { dialog.dismiss(); if (onNegative != null) onNegative.run(); });
            }

            btnPositive.setText(posText);
            btnPositive.setTextColor(Color.parseColor(posColorHex));
            btnPositive.setOnClickListener(v -> { dialog.dismiss(); if (onPositive != null) onPositive.run(); });

            dialog.show();
        } catch (Exception e) {
            if (onPositive != null) onPositive.run();
        }
    }

    private void showNavigationWarningDialog(int targetItemId) {
        showCustomDialog("Discard Changes?", "Are you sure you want to discard your current progress and leave this page?", "Discard", "Cancel", "#D32F2F", () -> navigateAway(targetItemId), null);
    }

    private void confirmUpdate() {
        if (!validateInputs()) return;
        showCustomDialog("Save Activity", "Do you want to save this activity or discard your changes?", "Save", "Discard", "#2E7D32", this::executeSave, this::returnToActivityLog);
    }

    private void confirmDelete() {
        showCustomDialog("Delete Activity", "Do you want to continue deletion or cancel?", "Continue", "Cancel", "#D32F2F", () -> {
            try {
                dbHelper.deleteActivity(editId);
                Toast.makeText(requireContext(), "Activity Deleted!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {}
            returnToActivityLog();
        }, this::returnToActivityLog);
    }

    private void returnToActivityLog() {
        if (!isAdded() || getActivity() == null) return;
        getActivity().getSupportFragmentManager().popBackStack();
        if (getActivity() instanceof Aera) {
            ((Aera) getActivity()).updateBottomNavSelection(R.id.nav_activity);
            ((Aera) getActivity()).setBottomNavigationVisibility(true);
        }
    }

    private void navigateAway(int itemId) {
        if (itemId == -1) { returnToActivityLog(); return; }
        if (!isAdded() || getActivity() == null) return;
        requireActivity().getSupportFragmentManager().popBackStack();

        Fragment selectedFragment = null;
        if (itemId == R.id.nav_home) selectedFragment = new HomePageFragment();
        else if (itemId == R.id.nav_analytics) selectedFragment = new AnalyticsFragment();
        else if (itemId == R.id.nav_goals) selectedFragment = new GoalsFragment();
        else if (itemId == R.id.nav_settings) selectedFragment = new SettingsFragment();

        if (selectedFragment != null) {
            getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();
            if (getActivity() instanceof Aera) {
                ((Aera) getActivity()).updateBottomNavSelection(itemId);
                ((Aera) getActivity()).setBottomNavigationVisibility(true);
            }
        }
    }

    private void setSpinnerSelection(Spinner spinner, String value) {
        if (spinner == null || spinner.getAdapter() == null) return;
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(value)) {
                spinner.setSelection(i);
                break;
            }
        }
    }

    private void selectCategoryChip(String category) {
        if (chipGroup == null) return;
        switch (category) {
            case "Transport": chipGroup.check(R.id.chip_transport); break;
            case "Energy": chipGroup.check(R.id.chip_energy); break;
            case "Food": chipGroup.check(R.id.chip_food); break;
            case "Shopping": chipGroup.check(R.id.chip_shopping); break;
            case "Waste": chipGroup.check(R.id.chip_waste); break;
        }
    }

    private void initData() {
        transportFactors.put("Motorcycle", 0.266);
        transportFactors.put("Tricycle", 0.266);
        transportFactors.put("Car", 0.319);
        transportFactors.put("Taxi", 0.292);
        transportFactors.put("Jeepney", 0.415);
        transportFactors.put("Bus", 1.097);
        transportFactors.put("UV/Van", 0.415);

        foodFactors.put("High-Impact Meat", 27.0);
        foodFactors.put("Medium-Impact Meat", 8.0);
        foodFactors.put("Low-Impact Meat", 6.0);
        foodFactors.put("Seafood", 5.0);
        foodFactors.put("Dairy & Eggs", 4.0);
        foodFactors.put("Grains & Staples", 2.5);
        foodFactors.put("Fruits & Vegetables", 0.9);
        foodFactors.put("Legumes & Plant-Based", 1.0);
        foodFactors.put("Processed & Packaged", 2.5);
        foodFactors.put("Sweets & Desserts", 5.0);
        foodFactors.put("Beverages", 1.5);

        shoppingFactors.put("Clothing & Footwear", 15.0);
        shoppingFactors.put("Electronics", 100.0);
        shoppingFactors.put("Furniture", 50.0);
        shoppingFactors.put("Household Products", 5.0);
        shoppingFactors.put("Personal Care", 2.0);
        shoppingFactors.put("Paper Products", 1.5);
        shoppingFactors.put("Plastic Products", 3.0);
        shoppingFactors.put("Other Retail Goods", 5.0);

        wasteFactors.put("Food Waste", 0.5);
        wasteFactors.put("Paper & Cardboard", 1.5);
        wasteFactors.put("Plastic", 3.0);
        wasteFactors.put("Glass", 0.9);
        wasteFactors.put("Metal", 2.0);
        wasteFactors.put("Textiles", 5.0);
        wasteFactors.put("Electronic Waste", 20.0);
        wasteFactors.put("Mixed/General Waste", 2.0);
    }

    private void initViews(View view) {
        layoutTransport = view.findViewById(R.id.layout_transport);
        layoutEnergy = view.findViewById(R.id.layout_energy);
        layoutFood = view.findViewById(R.id.layout_food);
        layoutShopping = view.findViewById(R.id.layout_shopping);
        layoutWaste = view.findViewById(R.id.layout_waste);
        chipGroup = view.findViewById(R.id.chip_group_category);

        btnSave = view.findViewById(R.id.btn_save);
        btnDelete = view.findViewById(R.id.btn_delete);
        tvTitle = view.findViewById(R.id.tv_page_title);
        tvEstimatedFootprint = view.findViewById(R.id.tv_estimated_footprint);

        spinnerTransport = view.findViewById(R.id.spinner_transport_type);
        spinnerFood = view.findViewById(R.id.spinner_food);
        spinnerShopping = view.findViewById(R.id.spinner_shopping);
        spinnerWaste = view.findViewById(R.id.spinner_waste);

        etDistance = view.findViewById(R.id.et_distance);
        etTrips = view.findViewById(R.id.et_trips);
        etPassengers = view.findViewById(R.id.et_passengers);
        etKwh = view.findViewById(R.id.et_kwh);

        etFoodAmount = view.findViewById(R.id.et_food_amount);
        etShoppingAmount = view.findViewById(R.id.et_shopping_amount);
        etWasteAmount = view.findViewById(R.id.et_waste_amount);

        setupSpinner(spinnerTransport, transportFactors.keySet().toArray(new String[0]));
        setupSpinner(spinnerFood, foodFactors.keySet().toArray(new String[0]));
        setupSpinner(spinnerShopping, shoppingFactors.keySet().toArray(new String[0]));
        setupSpinner(spinnerWaste, wasteFactors.keySet().toArray(new String[0]));
    }

    private void setupCategorySwitching() {
        if (chipGroup == null) return;

        chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int checkedId = checkedIds.get(0);

            if (layoutTransport != null) layoutTransport.setVisibility(View.GONE);
            if (layoutEnergy != null) layoutEnergy.setVisibility(View.GONE);
            if (layoutFood != null) layoutFood.setVisibility(View.GONE);
            if (layoutShopping != null) layoutShopping.setVisibility(View.GONE);
            if (layoutWaste != null) layoutWaste.setVisibility(View.GONE);

            if (!isInitializingEdit) {
                if (etDistance != null) etDistance.setText("");
                if (etTrips != null) etTrips.setText("");
                if (etPassengers != null) etPassengers.setText("");
                if (etKwh != null) etKwh.setText("");
                if (etFoodAmount != null) etFoodAmount.setText("");
                if (etShoppingAmount != null) etShoppingAmount.setText("");
                if (etWasteAmount != null) etWasteAmount.setText("");
            }

            if (checkedId == R.id.chip_transport) {
                currentCategory = "Transport";
                if (layoutTransport != null) layoutTransport.setVisibility(View.VISIBLE);
            } else if (checkedId == R.id.chip_energy) {
                currentCategory = "Energy";
                if (layoutEnergy != null) layoutEnergy.setVisibility(View.VISIBLE);
            } else if (checkedId == R.id.chip_food) {
                currentCategory = "Food";
                if (layoutFood != null) layoutFood.setVisibility(View.VISIBLE);
            } else if (checkedId == R.id.chip_shopping) {
                currentCategory = "Shopping";
                if (layoutShopping != null) layoutShopping.setVisibility(View.VISIBLE);
            } else if (checkedId == R.id.chip_waste) {
                currentCategory = "Waste";
                if (layoutWaste != null) layoutWaste.setVisibility(View.VISIBLE);
            }
            calculateFootprint();
        });
    }

    private void setupSpinner(Spinner spinner, String[] items) {
        if (spinner == null) return;
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(R.layout.item_spinner_dropdown);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                calculateFootprint();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupRealTimeCalculation() {
        TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { calculateFootprint(); }
            @Override public void afterTextChanged(Editable s) {}
        };
        if (etDistance != null) etDistance.addTextChangedListener(tw);
        if (etTrips != null) etTrips.addTextChangedListener(tw);
        if (etPassengers != null) etPassengers.addTextChangedListener(tw);
        if (etKwh != null) etKwh.addTextChangedListener(tw);
        if (etFoodAmount != null) etFoodAmount.addTextChangedListener(tw);
        if (etShoppingAmount != null) etShoppingAmount.addTextChangedListener(tw);
        if (etWasteAmount != null) etWasteAmount.addTextChangedListener(tw);
    }

    private void calculateFootprint() {
        double result = 0;
        switch (currentCategory) {
            case "Transport":
                if (spinnerTransport != null && spinnerTransport.getSelectedItem() != null) {
                    double dist = getDouble(etDistance);
                    double trips = getDouble(etTrips);
                    double pass = getDouble(etPassengers);

                    if (pass > 0 && trips > 0) {
                        result = (dist * trips * transportFactors.getOrDefault(spinnerTransport.getSelectedItem().toString(), 0.0)) / pass;
                    }
                }
                break;
            case "Energy":
                result = getDouble(etKwh) * 0.70;
                break;
            case "Food":
                if (spinnerFood != null && spinnerFood.getSelectedItem() != null)
                    result = getDouble(etFoodAmount) * foodFactors.getOrDefault(spinnerFood.getSelectedItem().toString(), 0.0);
                break;
            case "Shopping":
                if (spinnerShopping != null && spinnerShopping.getSelectedItem() != null)
                    result = getDouble(etShoppingAmount) * shoppingFactors.getOrDefault(spinnerShopping.getSelectedItem().toString(), 0.0);
                break;
            case "Waste":
                if (spinnerWaste != null && spinnerWaste.getSelectedItem() != null)
                    result = getDouble(etWasteAmount) * wasteFactors.getOrDefault(spinnerWaste.getSelectedItem().toString(), 0.0);
                break;
        }
        if (tvEstimatedFootprint != null) {
            tvEstimatedFootprint.setText(String.format(java.util.Locale.getDefault(), "%.2f kg CO₂e", result));
        }
    }

    private void saveEntry() {
        if (!validateInputs()) return;
        showCustomDialog("Save Activity", "Are you sure you want to log this activity?", "Save", "Cancel", "#2E7D32", this::executeSave, null);
    }

    private void executeSave() {
        double co2e = 0;
        try {
            if (tvEstimatedFootprint != null) {
                co2e = Double.parseDouble(tvEstimatedFootprint.getText().toString().split(" ")[0]);
            }
        } catch (Exception e) {}

        String subtype = "";
        double val = 0;
        switch (currentCategory) {
            case "Transport":
                subtype = (spinnerTransport != null && spinnerTransport.getSelectedItem() != null) ? spinnerTransport.getSelectedItem().toString() : "Unknown";
                val = getDouble(etDistance);
                break;
            case "Energy":
                subtype = "Electricity";
                val = getDouble(etKwh);
                break;
            case "Food":
                subtype = (spinnerFood != null && spinnerFood.getSelectedItem() != null) ? spinnerFood.getSelectedItem().toString() : "Unknown";
                val = getDouble(etFoodAmount);
                break;
            case "Shopping":
                subtype = (spinnerShopping != null && spinnerShopping.getSelectedItem() != null) ? spinnerShopping.getSelectedItem().toString() : "Unknown";
                val = getDouble(etShoppingAmount);
                break;
            case "Waste":
                subtype = (spinnerWaste != null && spinnerWaste.getSelectedItem() != null) ? spinnerWaste.getSelectedItem().toString() : "Unknown";
                val = getDouble(etWasteAmount);
                break;
        }

        try {
            if (editId == -1) {
                dbHelper.addActivity(currentCategory, subtype, val, co2e);
                Toast.makeText(requireContext(), "Activity Logged!", Toast.LENGTH_SHORT).show();
            } else {
                dbHelper.updateActivity(editId, currentCategory, subtype, val, co2e);
                Toast.makeText(requireContext(), "Activity Updated!", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {}

        returnToActivityLog();
    }

    private boolean validateInputs() {
        boolean valid = true;
        switch (currentCategory) {
            case "Transport":
                if (etDistance == null || etDistance.getText().toString().isEmpty()) {
                    if (etDistance != null) etDistance.setError("Required");
                    valid = false;
                }
                if (etTrips == null || etTrips.getText().toString().isEmpty()) {
                    if (etTrips != null) etTrips.setError("Required");
                    valid = false;
                }
                if (etPassengers == null || etPassengers.getText().toString().isEmpty()) {
                    if (etPassengers != null) etPassengers.setError("Required");
                    valid = false;
                }
                break;
            case "Energy":
                if (etKwh == null || etKwh.getText().toString().isEmpty()) {
                    if (etKwh != null) etKwh.setError("Required");
                    valid = false;
                }
                break;
            case "Food":
                if (etFoodAmount == null || etFoodAmount.getText().toString().isEmpty()) {
                    if (etFoodAmount != null) etFoodAmount.setError("Required");
                    valid = false;
                }
                break;
            case "Shopping":
                if (etShoppingAmount == null || etShoppingAmount.getText().toString().isEmpty()) {
                    if (etShoppingAmount != null) etShoppingAmount.setError("Required");
                    valid = false;
                }
                break;
            case "Waste":
                if (etWasteAmount == null || etWasteAmount.getText().toString().isEmpty()) {
                    if (etWasteAmount != null) etWasteAmount.setError("Required");
                    valid = false;
                }
                break;
        }
        return valid;
    }

    private double getDouble(EditText et) {
        if (et == null) return 0;
        try { return Double.parseDouble(et.getText().toString()); }
        catch (Exception e) { return 0; }
    }
}