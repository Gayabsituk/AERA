package com.example.aera;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class ActiveGoalAdapter extends RecyclerView.Adapter<ActiveGoalAdapter.ViewHolder> {

    public interface OnGoalClickListener {
        void onGoalClick(Goal goal);
    }

    private List<Goal> goalList;
    private final OnGoalClickListener listener;

    public ActiveGoalAdapter(OnGoalClickListener listener) {
        this.listener = listener;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void updateList(List<Goal> newList) {
        this.goalList = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_goals_set, parent, false);
        return new ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (goalList == null) return;
        Goal goal = goalList.get(position);

        holder.tvTitle.setText(goal.getTitle());
        holder.tvCategory.setText("Category: " + goal.getCategory());
        holder.tvDesc.setText(goal.getDescription());
        holder.tvProgress.setText(goal.getProgressPercentage() + "% completed");
        holder.progressBar.setProgress(goal.getProgressPercentage());

        holder.btnEdit.setOnClickListener(v -> {
            if (listener != null) listener.onGoalClick(goal);
        });

        // Calculate exact remaining time based on period and Philippine Time
        calculateAndDisplayTimeRemaining(goal, holder.tvTimeRemaining);
    }

    private void calculateAndDisplayTimeRemaining(Goal goal, TextView tvTimeRemaining) {
        if (tvTimeRemaining == null) return;

        // NEW: Check if the goal is already completed first
        if (goal.isCompleted()) {
            tvTimeRemaining.setText("Goal completed!");
            tvTimeRemaining.setTextColor(Color.parseColor("#2E7D32")); // Green color
            return; // Skip the time remaining calculation
        }

        TimeZone phTimeZone = TimeZone.getTimeZone("Asia/Manila");
        Calendar now = Calendar.getInstance(phTimeZone);

        // stores the time of creation of the goal
        long startTimeMillis = goal.getCreatedAt();
        if (startTimeMillis == 0) startTimeMillis = now.getTimeInMillis();

        Calendar deadline = Calendar.getInstance(phTimeZone);
        deadline.setTimeInMillis(startTimeMillis);

        String period = goal.getPeriod() != null ? goal.getPeriod().toLowerCase(Locale.getDefault()) : "weekly";

        // Add corresponding period offset based on creation day and time
        switch (period) {
            case "weekly":
                deadline.add(Calendar.WEEK_OF_YEAR, 1);
                break;
            case "monthly":
                deadline.add(Calendar.MONTH, 1);
                break;
            case "quarterly":
                deadline.add(Calendar.MONTH, 3);
                break;
            case "yearly":
                deadline.add(Calendar.YEAR, 1);
                break;
            default:
                deadline.add(Calendar.WEEK_OF_YEAR, 1);
                break;
        }

        long diffMillis = deadline.getTimeInMillis() - now.getTimeInMillis();

        if (diffMillis <= 0) {
            tvTimeRemaining.setText("Goal period ended");
            tvTimeRemaining.setTextColor(Color.parseColor("#B71C1C")); // Red
            return;
        }

        long seconds = diffMillis / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;

        long remHours = hours % 24;
        long remMinutes = minutes % 60;

        String timeRemainingText;
        if (days > 0) {
            timeRemainingText = String.format(Locale.getDefault(), " %d day%s, %d hr%s left", days, days == 1 ? "" : "s", remHours, remHours == 1 ? "" : "s");
        } else if (hours > 0) {
            timeRemainingText = String.format(Locale.getDefault(), " %d hour%s, %d min%s left", hours, hours == 1 ? "" : "s", remMinutes, remMinutes == 1 ? "" : "s");
        } else {
            timeRemainingText = String.format(Locale.getDefault(), " %d minute%s left", remMinutes, remMinutes == 1 ? "" : "s");
        }

        tvTimeRemaining.setText(timeRemainingText);
        tvTimeRemaining.setTextColor(Color.parseColor("#D97706")); // Orange/Amber
    }

    @Override
    public int getItemCount() {
        return goalList == null ? 0 : goalList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvCategory, tvDesc, tvProgress, tvTimeRemaining, btnEdit;
        ProgressBar progressBar;

        ViewHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_active_goal_title);
            tvCategory = itemView.findViewById(R.id.tv_active_goal_category);
            tvDesc = itemView.findViewById(R.id.tv_active_goal_desc);
            tvProgress = itemView.findViewById(R.id.tv_active_goal_progress);
            tvTimeRemaining = itemView.findViewById(R.id.tv_goal_time_remaining);
            btnEdit = itemView.findViewById(R.id.btn_edit_goal);
            progressBar = itemView.findViewById(R.id.progress_goal);
        }
    }
}