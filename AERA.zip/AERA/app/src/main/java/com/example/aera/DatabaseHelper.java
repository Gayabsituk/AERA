package com.example.aera;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.github.mikephil.charting.data.PieEntry;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "aera.db";
    private static final int DATABASE_VERSION = 4; // Incremented to 4 to add created_at column

    public static final String TABLE_ACTIVITY = "activities";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_SUBTYPE = "subtype";
    public static final String COLUMN_VALUE = "value";
    public static final String COLUMN_CO2E = "co2e";
    public static final String COLUMN_TIMESTAMP = "timestamp";

    public static final String TABLE_GOALS = "goals";
    public static final String COLUMN_GOAL_ID = "goal_id";
    public static final String COLUMN_GOAL_TITLE = "title";
    public static final String COLUMN_GOAL_DESC = "description";
    public static final String COLUMN_GOAL_TARGET = "target";
    public static final String COLUMN_GOAL_PROGRESS = "progress";
    public static final String COLUMN_GOAL_PERIOD = "period";
    public static final String COLUMN_GOAL_CATEGORY = "category";
    public static final String COLUMN_GOAL_COMPLETED = "is_completed";
    public static final String COLUMN_GOAL_CREATED_AT = "created_at"; // NEW: Timestamp Column

    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_ACTIVITY + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_TYPE + " TEXT, " +
                    COLUMN_SUBTYPE + " TEXT, " +
                    COLUMN_VALUE + " REAL, " +
                    COLUMN_CO2E + " REAL, " +
                    COLUMN_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP" +
                    ");";

    private static final String TABLE_GOALS_CREATE =
            "CREATE TABLE " + TABLE_GOALS + " (" +
                    COLUMN_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_GOAL_TITLE + " TEXT, " +
                    COLUMN_GOAL_DESC + " TEXT, " +
                    COLUMN_GOAL_TARGET + " INTEGER, " +
                    COLUMN_GOAL_PROGRESS + " INTEGER DEFAULT 0, " +
                    COLUMN_GOAL_PERIOD + " TEXT, " +
                    COLUMN_GOAL_CATEGORY + " TEXT, " +
                    COLUMN_GOAL_COMPLETED + " INTEGER DEFAULT 0, " +
                    COLUMN_GOAL_CREATED_AT + " INTEGER" + // NEW: Added to table schema
                    ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        db.execSQL(TABLE_GOALS_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ACTIVITY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOALS);
        onCreate(db);
    }

    public long addActivity(String type, String subtype, double value, double co2e) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TYPE, type);
        values.put(COLUMN_SUBTYPE, subtype);
        values.put(COLUMN_VALUE, value);
        values.put(COLUMN_CO2E, co2e);
        long id = db.insert(TABLE_ACTIVITY, null, values);
        updateGoalsProgress(type, co2e);
        return id;
    }

    private void updateGoalsProgress(String category, double co2e) {
        // Logic to update active goals progress could go here if needed
    }

    public List<ActivityEntry> getAllActivities() {
        List<ActivityEntry> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ACTIVITY, null, null, null, null, null, COLUMN_TIMESTAMP + " DESC");

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {
                        ActivityEntry entry = new ActivityEntry(
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TYPE)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SUBTYPE)),
                                cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_VALUE)),
                                cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_CO2E)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP))
                        );
                        list.add(entry);
                    } while (cursor.moveToNext());
                }
            } finally {
                cursor.close();
            }
        }
        return list;
    }

    public double getTotalFootprint() {
        SQLiteDatabase db = this.getReadableDatabase();
        double total = 0;
        Cursor cursor = db.rawQuery("SELECT SUM(" + COLUMN_CO2E + ") FROM " + TABLE_ACTIVITY, null);

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    total = cursor.getDouble(0);
                }
            } finally {
                cursor.close();
            }
        }
        return total;
    }

    public double getTodayTotalCO2() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(" + COLUMN_CO2E + ") FROM " + TABLE_ACTIVITY +
                " WHERE date(" + COLUMN_TIMESTAMP + ") = date('now', 'localtime')", null);
        double total = 0;

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    total = cursor.getDouble(0);
                }
            } finally {
                cursor.close();
            }
        }
        return total;
    }

    public List<PieEntry> getCategoryBreakdown(String period) {
        List<PieEntry> entries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String dateFilter = "";

        if ("day".equals(period)) {
            dateFilter = " WHERE date(" + COLUMN_TIMESTAMP + ") = date('now', 'localtime')";
        } else if ("week".equals(period)) {
            dateFilter = " WHERE date(" + COLUMN_TIMESTAMP + ") >= date('now', 'localtime', '-7 days')";
        } else if ("month".equals(period)) {
            dateFilter = " WHERE date(" + COLUMN_TIMESTAMP + ") >= date('now', 'localtime', '-30 days')";
        }

        String query = "SELECT " + COLUMN_TYPE + ", SUM(" + COLUMN_CO2E + ") FROM " + TABLE_ACTIVITY +
                dateFilter + " GROUP BY " + COLUMN_TYPE;

        Cursor cursor = db.rawQuery(query, null);
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {
                        entries.add(new PieEntry((float) cursor.getDouble(1), cursor.getString(0)));
                    } while (cursor.moveToNext());
                }
            } finally {
                cursor.close();
            }
        }
        return entries;
    }

    public float[] getDailyTotals(int days) {
        float[] totals = new float[days];
        SQLiteDatabase db = this.getReadableDatabase();

        for (int i = 0; i < days; i++) {
            String query = "SELECT SUM(" + COLUMN_CO2E + ") FROM " + TABLE_ACTIVITY +
                    " WHERE date(" + COLUMN_TIMESTAMP + ") = date('now', 'localtime', '-" + (days - 1 - i) + " days')";
            Cursor cursor = db.rawQuery(query, null);
            if (cursor != null) {
                try {
                    if (cursor.moveToFirst()) {
                        totals[i] = (float) cursor.getDouble(0);
                    }
                } finally {
                    cursor.close();
                }
            }
        }
        return totals;
    }

    public float[] getWeeklyTotalsForMonth() {
        float[] totals = new float[4];
        SQLiteDatabase db = this.getReadableDatabase();

        for (int i = 0; i < 4; i++) {
            String query = "SELECT SUM(" + COLUMN_CO2E + ") FROM " + TABLE_ACTIVITY +
                    " WHERE date(" + COLUMN_TIMESTAMP + ") <= date('now', 'localtime', '-" + (i * 7) + " days') " +
                    " AND date(" + COLUMN_TIMESTAMP + ") > date('now', 'localtime', '-" + ((i + 1) * 7) + " days')";
            Cursor cursor = db.rawQuery(query, null);
            if (cursor != null) {
                try {
                    if (cursor.moveToFirst()) {
                        totals[3 - i] = (float) cursor.getDouble(0);
                    }
                } finally {
                    cursor.close();
                }
            }
        }
        return totals;
    }

    // --- Goal Methods ---

    public long addGoal(String title, String desc, int target, String period, String category) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_TITLE, title);
        values.put(COLUMN_GOAL_DESC, desc);
        values.put(COLUMN_GOAL_TARGET, target);
        values.put(COLUMN_GOAL_PERIOD, period);
        values.put(COLUMN_GOAL_CATEGORY, category);
        values.put(COLUMN_GOAL_PROGRESS, 0);
        values.put(COLUMN_GOAL_COMPLETED, 0);
        values.put(COLUMN_GOAL_CREATED_AT, System.currentTimeMillis()); // NEW: Save current time in millis
        return db.insert(TABLE_GOALS, null, values);
    }

    public List<Goal> getAllActiveGoals() {
        List<Goal> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_GOALS, null, COLUMN_GOAL_COMPLETED + "=0", null, null, null, COLUMN_GOAL_ID + " DESC");

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {
                        list.add(new Goal(
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_ID)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_TITLE)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_DESC)),
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_TARGET)),
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_PROGRESS)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_PERIOD)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_CATEGORY)),
                                false,
                                cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_GOAL_CREATED_AT)) // NEW: Pass timestamp to constructor
                        ));
                    } while (cursor.moveToNext());
                }
            } finally {
                cursor.close();
            }
        }
        return list;
    }
    public void updateGoal(int id, String title, String desc, int target, String period, String category) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_TITLE, title);
        values.put(COLUMN_GOAL_DESC, desc);
        values.put(COLUMN_GOAL_TARGET, target);
        values.put(COLUMN_GOAL_PERIOD, period);
        values.put(COLUMN_GOAL_CATEGORY, category);

        // Updates the row where the ID matches
        db.update(TABLE_GOALS, values, COLUMN_GOAL_ID + " = ?", new String[]{String.valueOf(id)});
    }
    public List<Goal> getCompletedGoals() {
        List<Goal> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_GOALS, null, COLUMN_GOAL_COMPLETED + "=1", null, null, null, COLUMN_GOAL_ID + " DESC");

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {
                        list.add(new Goal(
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_ID)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_TITLE)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_DESC)),
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_TARGET)),
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_PROGRESS)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_PERIOD)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_CATEGORY)),
                                true,
                                cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_GOAL_CREATED_AT)) // NEW: Pass timestamp to constructor
                        ));
                    } while (cursor.moveToNext());
                }
            } finally {
                cursor.close();
            }
        }
        return list;
    }
}