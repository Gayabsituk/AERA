package com.example.aera;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.github.mikephil.charting.data.PieEntry;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "aera.db";
    private static final int DATABASE_VERSION = 8;

    public static final String TABLE_ACTIVITY = "activities";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_TYPE = "type";
    public static final String COLUMN_SUBTYPE = "subtype";
    public static final String COLUMN_VALUE = "value";
    public static final String COLUMN_CO2E = "co2e";
    public static final String COLUMN_TIMESTAMP = "timestamp";

    public static final String TABLE_GOALS = "goals";
    public static final String COLUMN_GOAL_ID = "goal_id";
    public static final String COLUMN_GOAL_USERNAME = "username";
    public static final String COLUMN_GOAL_TITLE = "title";
    public static final String COLUMN_GOAL_DESC = "description";
    public static final String COLUMN_GOAL_TARGET = "target";
    public static final String COLUMN_GOAL_PROGRESS = "progress";
    public static final String COLUMN_GOAL_PERIOD = "period";
    public static final String COLUMN_GOAL_CATEGORY = "category";
    public static final String COLUMN_GOAL_COMPLETED = "is_completed";
    public static final String COLUMN_GOAL_CREATED_AT = "created_at";

    public static final String TABLE_USER = "user_profile";
    public static final String COLUMN_USER_KEY = "key";
    public static final String COLUMN_USER_VALUE = "value";

    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_ACTIVITY + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT, " +
                    COLUMN_TYPE + " TEXT, " +
                    COLUMN_SUBTYPE + " TEXT, " +
                    COLUMN_VALUE + " REAL, " +
                    COLUMN_CO2E + " REAL, " +
                    COLUMN_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP" +
                    ");";

    private static final String TABLE_GOALS_CREATE =
            "CREATE TABLE " + TABLE_GOALS + " (" +
                    COLUMN_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_GOAL_USERNAME + " TEXT, " +
                    COLUMN_GOAL_TITLE + " TEXT, " +
                    COLUMN_GOAL_DESC + " TEXT, " +
                    COLUMN_GOAL_TARGET + " INTEGER, " +
                    COLUMN_GOAL_PROGRESS + " INTEGER DEFAULT 0, " +
                    COLUMN_GOAL_PERIOD + " TEXT, " +
                    COLUMN_GOAL_CATEGORY + " TEXT, " +
                    COLUMN_GOAL_COMPLETED + " INTEGER DEFAULT 0, " +
                    COLUMN_GOAL_CREATED_AT + " INTEGER" +
                    ");";

    private static final String TABLE_USER_CREATE = "CREATE TABLE user_profile (`key` TEXT PRIMARY KEY, value TEXT);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        db.execSQL(TABLE_GOALS_CREATE);
        db.execSQL(TABLE_USER_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ACTIVITY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOALS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        onCreate(db);
    }

    public void setUserName(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_KEY, "user_name");
        values.put(COLUMN_USER_VALUE, name);

        int rows = db.update(TABLE_USER, values, COLUMN_USER_KEY + " = ?", new String[]{"user_name"});
        if (rows == 0) {
            db.insert(TABLE_USER, null, values);
        }
    }

    public String getUserName() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER, new String[]{COLUMN_USER_VALUE},
                COLUMN_USER_KEY + " = ?", new String[]{"user_name"}, null, null, null);
        String name = "";
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    name = cursor.getString(0);
                }
            } finally {
                cursor.close();
            }
        }
        return name;
    }

    public long addActivity(String type, String subtype, double value, double co2e) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, getUserName());
        values.put(COLUMN_TYPE, type);
        values.put(COLUMN_SUBTYPE, subtype);
        values.put(COLUMN_VALUE, value);
        values.put(COLUMN_CO2E, co2e);
        long id = db.insert(TABLE_ACTIVITY, null, values);
        updateGoalsProgress(type, co2e);
        return id;
    }

    public void deleteActivity(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_ACTIVITY, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public void updateActivity(int id, String type, String subtype, double value, double co2e) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TYPE, type);
        values.put(COLUMN_SUBTYPE, subtype);
        values.put(COLUMN_VALUE, value);
        values.put(COLUMN_CO2E, co2e);
        db.update(TABLE_ACTIVITY, values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    private void updateGoalsProgress(String category, double co2e) {}

    public List<ActivityEntry> getAllActivities() {
        List<ActivityEntry> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selection = COLUMN_USERNAME + " = ? AND date(" + COLUMN_TIMESTAMP + ") = date('now', 'localtime')";
        Cursor cursor = db.query(TABLE_ACTIVITY, null, selection, new String[]{getUserName()}, null, null, COLUMN_TIMESTAMP + " DESC");

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {
                        ActivityEntry entry = new ActivityEntry(
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TYPE)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SUBTYPE)),
                                cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_VALUE)),
                                cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_CO2E)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP))
                        );
                        list.add(entry);
                    } while (cursor.moveToNext());
                }
            } finally {
                cursor.close();
            }
        }
        return list;
    }

    public List<Goal> getUnfinishedGoals() {
        List<Goal> allActive = getAllActiveGoals();
        List<Goal> unfinished = new ArrayList<>();
        long currentTime = System.currentTimeMillis();

        for (Goal goal : allActive) {
            long durationMillis = 0;

            if ("Weekly".equalsIgnoreCase(goal.getPeriod())) {
                durationMillis = 7L * 24 * 60 * 60 * 1000;
            } else if ("Monthly".equalsIgnoreCase(goal.getPeriod())) {
                durationMillis = 30L * 24 * 60 * 60 * 1000;
            } else if ("Yearly".equalsIgnoreCase(goal.getPeriod())) {
                durationMillis = 365L * 24 * 60 * 60 * 1000;
            }

            if (durationMillis > 0 && (currentTime - goal.getCreatedAt()) > durationMillis) {
                unfinished.add(goal);
            }
        }
        return unfinished;
    }

    public double getTotalFootprint() {
        SQLiteDatabase db = this.getReadableDatabase();
        double total = 0;
        Cursor cursor = db.rawQuery("SELECT SUM(" + COLUMN_CO2E + ") FROM " + TABLE_ACTIVITY + " WHERE " + COLUMN_USERNAME + " = ?", new String[]{getUserName()});

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    total = cursor.getDouble(0);
                }
            } finally {
                cursor.close();
            }
        }
        return total;
    }

    public double getTodayTotalCO2() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(" + COLUMN_CO2E + ") FROM " + TABLE_ACTIVITY +
                " WHERE date(" + COLUMN_TIMESTAMP + ") = date('now', 'localtime') AND " + COLUMN_USERNAME + " = ?", new String[]{getUserName()});
        double total = 0;

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    total = cursor.getDouble(0);
                }
            } finally {
                cursor.close();
            }
        }
        return total;
    }

    public List<PieEntry> getCategoryBreakdown(String period) {
        List<PieEntry> entries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String dateFilter = "";

        if ("day".equals(period)) {
            dateFilter = " WHERE date(" + COLUMN_TIMESTAMP + ") = date('now', 'localtime') AND " + COLUMN_USERNAME + " = ?";
        } else if ("week".equals(period)) {
            dateFilter = " WHERE date(" + COLUMN_TIMESTAMP + ") >= date('now', 'localtime', '-7 days') AND " + COLUMN_USERNAME + " = ?";
        } else if ("month".equals(period)) {
            dateFilter = " WHERE date(" + COLUMN_TIMESTAMP + ") >= date('now', 'localtime', '-30 days') AND " + COLUMN_USERNAME + " = ?";
        }

        String query = "SELECT " + COLUMN_TYPE + ", SUM(" + COLUMN_CO2E + ") FROM " + TABLE_ACTIVITY +
                dateFilter + " GROUP BY " + COLUMN_TYPE;

        Cursor cursor = db.rawQuery(query, new String[]{getUserName()});
        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {
                        entries.add(new PieEntry((float) cursor.getDouble(1), cursor.getString(0)));
                    } while (cursor.moveToNext());
                }
            } finally {
                cursor.close();
            }
        }
        return entries;
    }

    public float[] getDailyTotals(int days) {
        float[] totals = new float[days];
        SQLiteDatabase db = this.getReadableDatabase();
        String currentUser = getUserName();

        for (int i = 0; i < days; i++) {
            String query = "SELECT SUM(" + COLUMN_CO2E + ") FROM " + TABLE_ACTIVITY +
                    " WHERE date(" + COLUMN_TIMESTAMP + ") = date('now', 'localtime', '-" + (days - 1 - i) + " days') AND " + COLUMN_USERNAME + " = ?";
            Cursor cursor = db.rawQuery(query, new String[]{currentUser});
            if (cursor != null) {
                try {
                    if (cursor.moveToFirst()) {
                        totals[i] = (float) cursor.getDouble(0);
                    }
                } finally {
                    cursor.close();
                }
            }
        }
        return totals;
    }

    public float[] getWeeklyTotalsForMonth() {
        float[] totals = new float[4];
        SQLiteDatabase db = this.getReadableDatabase();
        String currentUser = getUserName();

        for (int i = 0; i < 4; i++) {
            String query = "SELECT SUM(" + COLUMN_CO2E + ") FROM " + TABLE_ACTIVITY +
                    " WHERE date(" + COLUMN_TIMESTAMP + ") <= date('now', 'localtime', '-" + (i * 7) + " days') " +
                    " AND date(" + COLUMN_TIMESTAMP + ") > date('now', 'localtime', '-" + ((i + 1) * 7) + " days') AND " + COLUMN_USERNAME + " = ?";
            Cursor cursor = db.rawQuery(query, new String[]{currentUser});
            if (cursor != null) {
                try {
                    if (cursor.moveToFirst()) {
                        totals[3 - i] = (float) cursor.getDouble(0);
                    }
                } finally {
                    cursor.close();
                }
            }
        }
        return totals;
    }

    public long addGoal(String title, String desc, int target, String period, String category) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_USERNAME, getUserName());
        values.put(COLUMN_GOAL_TITLE, title);
        values.put(COLUMN_GOAL_DESC, desc);
        values.put(COLUMN_GOAL_TARGET, target);
        values.put(COLUMN_GOAL_PERIOD, period);
        values.put(COLUMN_GOAL_CATEGORY, category);
        values.put(COLUMN_GOAL_PROGRESS, 0);
        values.put(COLUMN_GOAL_COMPLETED, 0);
        values.put(COLUMN_GOAL_CREATED_AT, System.currentTimeMillis());
        return db.insert(TABLE_GOALS, null, values);
    }

    public List<Goal> getAllActiveGoals() {
        List<Goal> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_GOALS, null, COLUMN_GOAL_COMPLETED + "=0 AND " + COLUMN_GOAL_USERNAME + "=?", new String[]{getUserName()}, null, null, COLUMN_GOAL_ID + " DESC");

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {
                        list.add(new Goal(
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_ID)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_TITLE)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_DESC)),
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_TARGET)),
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_PROGRESS)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_PERIOD)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_CATEGORY)),
                                false,
                                cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_GOAL_CREATED_AT))
                        ));
                    } while (cursor.moveToNext());
                }
            } finally {
                cursor.close();
            }
        }
        return list;
    }

    public void updateGoal(int id, String title, String desc, int target, String period, String category) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_TITLE, title);
        values.put(COLUMN_GOAL_DESC, desc);
        values.put(COLUMN_GOAL_TARGET, target);
        values.put(COLUMN_GOAL_PERIOD, period);
        values.put(COLUMN_GOAL_CATEGORY, category);
        values.put(COLUMN_GOAL_CREATED_AT, System.currentTimeMillis());

        db.update(TABLE_GOALS, values, COLUMN_GOAL_ID + " = ? AND " + COLUMN_GOAL_USERNAME + " = ?", new String[]{String.valueOf(id), getUserName()});
    }

    public void deleteGoal(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_GOALS, COLUMN_GOAL_ID + " = ? AND " + COLUMN_GOAL_USERNAME + " = ?", new String[]{String.valueOf(id), getUserName()});
    }

    public List<Goal> getCompletedGoals() {
        List<Goal> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_GOALS, null, COLUMN_GOAL_COMPLETED + "=1 AND " + COLUMN_GOAL_USERNAME + "=?", new String[]{getUserName()}, null, null, COLUMN_GOAL_ID + " DESC");

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    do {
                        list.add(new Goal(
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_ID)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_TITLE)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_DESC)),
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_TARGET)),
                                cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_PROGRESS)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_PERIOD)),
                                cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_GOAL_CATEGORY)),
                                true,
                                cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_GOAL_CREATED_AT))
                        ));
                    } while (cursor.moveToNext());
                }
            } finally {
                cursor.close();
            }
        }
        return list;
    }

    public void clearUserSession() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_USER, null, null);
    }
}