plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.aera"
    compileSdk = 37 // Just setting this standard, though you had release(37)

    defaultConfig {
        applicationId = "com.example.aera"
        minSdk = 24
        targetSdk = 37 // Targeting stable API versions
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false // Adjusted to standard Gradle Kotlin DSL
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.activity.ktx)
    implementation(libs.appcompat)
    implementation(libs.constraintlayout)
    implementation(libs.material)

    // <--- ADDED THIS LINE FOR THE CHARTS --->
    implementation("com.github.PhilJay:MPAndroidChart:v3.1.0")

    testImplementation(libs.junit)
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.ext.junit)
}